`<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_ADMIN_ID'];
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <div class="col-10">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <form method="post" action="action/funds_save.php" class="forms" autocomplete="off" enctype="multipart/form-data"> 
                    	<div class="row">  
                            <div class="col-md-6">
                                <label>People</label>
                                <input list="people" required class="form-control" name="people" id="peoples">
                                <datalist id="people">
                                    <option value="">Select</option> 
                                    <?php
                                       $result = $db->prepare("SELECT distinct(name) FROM complaints where aststus='clear' and dstatus='pending'");
                                            $result->execute();
                                            $row_count =  $result->rowcount();
                                            for($i=0; $rows = $result->fetch(); $i++)
                                            {
                                            echo '<option>'.$rows['name'].'</option>';
                                            }
                                        ?>	  
                                </datalist>                  
                            </div>  
                            <div class="col-md-6">
                                <label>Gender</label>
                                <input type="text"  name="sex" class="form-control" id="sex">                        
                            </div> 
                       </div>
                       <div class="row">  
                            <div class="col-md-6">
                                <label>Age</label>
                                    <input type="text"  name="age" class="form-control" id="age">                  
                            </div> 
                            <div class="col-md-6">
                                <label>Address</label>
                                  <input type="text"  name="addrs" class="form-control" id="addrs">
                            </div> 
                       </div>
                       <div class="row">  
                            <div class="col-md-6">
                                <label>Aadhar No</label>
                                    <input type="text"  name="aadharno" class="form-control" id="aadharno">                 
                            </div>                     
                            <div class="col-md-6">
                                <label>District</label>
                                     <input list="district" required class="form-control" name="district">
                                    <datalist id="district">
                                        <option value="">Select</option> 
                                         <?php
                                       $result = $db->prepare("SELECT distinct(district) FROM funds");
                                            $result->execute();
                                            $row_count =  $result->rowcount();
                                            for($i=0; $rows = $result->fetch(); $i++)
                                            {
                                            echo '<option>'.$rows['district'].'</option>';
                                            }
                                        ?>	 
                                    </datalist>   
                            </div>  
                        </div>
                       <div class="row">  
                            <div class="col-md-6">
                                <label>Panchayath</label>
                                     <input list="panchayath" required class="form-control" name="panchayath">
                                    <datalist id="panchayath">
                                        <option value="">Select</option> 
                                         <?php
                                       $result = $db->prepare("SELECT distinct(panchayath) FROM funds");
                                            $result->execute();
                                            $row_count =  $result->rowcount();
                                            for($i=0; $rows = $result->fetch(); $i++)
                                            {
                                            echo '<option>'.$rows['panchayath'].'</option>';
                                            }
                                        ?>	 
                                    </datalist>        
                            </div>    
                            <div class="col-md-6">
                                <label>Village</label>
                                     <input list="village" required class="form-control" name="village">
                                     <datalist id="village">
                                        <option value="">Select</option> 
                                         <?php
                                       $result = $db->prepare("SELECT distinct(village) FROM funds");
                                            $result->execute();
                                            $row_count =  $result->rowcount();
                                            for($i=0; $rows = $result->fetch(); $i++)
                                            {
                                            echo '<option>'.$rows['village'].'</option>';
                                            }
                                        ?>	 
                                    </datalist>   
                            </div>
                        </div>
                       <div class="row">  
                            <div class="col-md-6">
                                <label>Bank</label>
                                     <input list="bank" required class="form-control" name="bank">
                                     <datalist id="bank">
                                        <option value="">Select</option> 
                                         <?php
                                       $result = $db->prepare("SELECT distinct(bank) FROM funds");
                                            $result->execute();
                                            $row_count =  $result->rowcount();
                                            for($i=0; $rows = $result->fetch(); $i++)
                                            {
                                            echo '<option>'.$rows['bank'].'</option>';
                                            }
                                        ?>	 
                                    </datalist>   
                            </div>
                            <div class="col-md-6">
                                <label>Account No</label>
                                    <input type="text" class="form-control" name="accno" required>        
                            </div>    
                       </div>
                       <div class="row">                    
                            <div class="col-md-6">
                                <label>Amount</label>
                                    <input type="number" class="form-control" name="amnt" required min="0" step="0.01">        
                            </div>
                            <div class="col-md-6">
                                <label>Issue</label>
                                    <input type="number" class="form-control" name="issun" required min="0" step="0.01">        
                            </div>
                       </div>
                       <div class="row">  
                             <div class="col-md-6">
                                <label>Officer Name</label>
                                    <input type="text" class="form-control" name="offname" required>        
                            </div>
                             <div class="col-md-6">
                                <label>Funds Date</label>
                                    <input type="date" class="form-control" name="fdate" required max="<?php echo date("Y-m-d");?>">        
                            </div>
                        </div>
                       <div class="row">  
                             <div class="col-md-6">
                                <label>Issue Date</label>
                                    <input type="date" class="form-control" name="idate" required min="<?php echo date("Y-m-d");?>">        
                            </div>
                             <div class="col-md-6">
                                <label>Issue Photo</label>
                                    <input type="file" class="form-control" name="iphoto" required accept=".png, .jpg, .jpeg">        
                            </div>
                         </div>
                       <div class="row">  
                           <div class="col-md-6">
                            <label>People Photo</label>
                        		<input type="file" class="form-control" name="photo" required accept=".png, .jpg, .jpeg">        
                          </div>
                           <div class="col-md-6">
                                <label>Description</label>
                                    <textarea name="desp" class="form-control" required rows="1"></textarea>
                            </div> 
                       </div>                                                                                                
                        <div class="col-xs-12 text-right">
                                <br>
                                <input type="submit" value="Submit" class="btn float-right btn-primary">
                            </div>
                    </form>
                    
                  </div>
                </div>
              </div>
                <!-- New End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
  
<script type="text/javascript">
$(document).ready(function()
{
	$('#peoples').change(function()
	{
		
		var peoples = $("#peoples").val();
		$.ajax({				
			type:'POST',
			url:'funds_select.php',
			data:'peoples='+peoples,	
			dataType:"JSON",			
			success:function(data)
			{				
			   $('#name').val(data.name); 
			   $('#sex').val(data.sex);    
			   $('#age').val(data.age);
			   $('#addrs').val(data.addrs);   
			   $('#aadharno').val(data.aadharno);
			}				
		}); 						
	});			
});
</script>
</body>

</html>


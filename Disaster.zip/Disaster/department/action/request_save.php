<?php
include("../../connect/db.php");
	
	$Log_Id=$_POST["Log_Id"];
	$qty=$_POST["qty"];
	$subj=$_POST["subj"];
	$fdate=$_POST["fdate"];
	$tdate=$_POST["tdate"];
	$ttime=$_POST["ttime"];
	$servce=$_POST["servce"];
	
	$image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
	$image_name = addslashes($_FILES['photo']['name']);
	$image_size = getimagesize($_FILES['photo']['tmp_name']);
	move_uploaded_file($_FILES["photo"]["tmp_name"], "../../photo/" . $_FILES["photo"]["name"]);
	$photo = $_FILES["photo"]["name"];
	
		
$sql = "insert into rquest_emergncy(Log_Id,qty,subj,fdate,tdate,ttime,photo,servce)values('$Log_Id','$qty','$subj','$fdate','$tdate','$ttime','$photo','$servce')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../em_request_post.php");
?>

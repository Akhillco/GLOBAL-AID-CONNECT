<?php
include("../../connect/db.php");

	$name=$_POST["name"];
	$subj=$_POST["subj"];
	$about=$_POST["about"];
	$Log_Id=$_POST["Log_Id"];
	$cntno=$_POST["cntno"];
	$photo=$_POST["photo"];
	
	$sstatus="Pending";
	
	$date=date("d-m-Y");
	
	date_default_timezone_set('Asia/Kolkata');
	$tm = date( 'h:i:s A', time () );

	
$sql = "insert into message(name,subj,about,sdate,stime,Log_Id,cntno,sstatus,photo)values('$name','$subj','$about','$date','$tm','$Log_Id','$cntno','$sstatus','$photo')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../message_view.php");
?>

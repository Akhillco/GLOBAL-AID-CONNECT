<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_VOL_ID'];
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
   <link rel="stylesheet" href="vendors/datatables.net-bs4/dataTables.bootstrap4.css">
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">All Volunteers</h4>
                    <div class="row">
                      <div class="col-12">
                        <div class="table-responsive">
                          <table id="order-listing" class="table">
                            <thead>
                              		<th>#</th>
                                    <th>Name</th>
                                    <th>Age</th>
                                    <th>Gender</th>
                                    <th>Contact</th>
                                    <th>Email</th>
                                    <th>Blood</th>
                                    <th>Location</th>
                                    <th>Qualification</th>
                                    <th>Service</th>
                            </thead>
                            <tbody>
                             <?php
								$result = $db->prepare("select * from  volunteer where Log_Id !='$Log_Id'");
								$result->execute();
								for($i=1; $row = $result->fetch(); $i++)
									{
									$voln_id = $row['voln_id'];	
									echo"<tr>";						
										echo"<td>".$i."</td>";
										echo"<td>".$row["name"]."</td>";
										echo"<td>".$row["age"]."</td>";	
										echo"<td>".$row["sex"]."</td>";	
										echo"<td>".$row["contactno"]."</td>";	
										echo"<td>".$row["email"]."</td>";	
										echo"<td>".$row["blgrp"]."</td>";
										echo"<td>".$row["location"]."</td>";
										echo"<td>".$row["qulf"]."</td>";	
										echo"<td>".$row["servce"]."</td>";																									
									echo"</tr>";
									}
								?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                <!-- New End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
   <script src="vendors/datatables.net/jquery.dataTables.js"></script>
   <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
   <script src="js/data-table.js"></script>
</body>

</html>


<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_DEPT_ID'];
	$result = $db->prepare("select * from department where Log_Id='$Log_Id'");
	$result->execute();
	for ($i = 0; $row = $result->fetch(); $i++) 
	{
			
		$photo= $row['photo'];
	}
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <div class="col-md-9 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title alert alert-info">New Land Slide  / Any Disaster Place Register</h4>
                           
                            <form method="post" action="action/disaster_save.php" class="forms" autocomplete="off" enctype="multipart/form-data">   
                            <div class="row">
                              <div class="col-md-6">
                                    <label>Name</label>
                                    <input list="name" required class="form-control" name="name">
                                        <datalist id="name">
                                            <option value="">Select</option> 
                                              <?php
                                               $result = $db->prepare("SELECT distinct(name) FROM disaster");
                                                    $result->execute();
                                                    $row_count =  $result->rowcount();
                                                    for($i=0; $rows = $result->fetch(); $i++)
                                                    {
                                                    echo '<option>'.$rows['name'].'</option>';
                                                    }
                                                ?>	                                 					
                                        </datalist>                  
                                </div>                          
                                <div class="col-md-6">
                                    <label>Address</label>
                                      <input type="text"  name="addrs" class="form-control" required >
                                </div>
                            </div>  
                            <div class="row">                                         
                                <div class="col-md-6">
                                    <label>District</label>
                                    <input list="district" required class="form-control" name="district">
                                        <datalist id="district">
                                            <option value="">Select</option> 
											 <?php
                                           $result = $db->prepare("SELECT distinct(district) FROM disaster");
                                                $result->execute();
                                                $row_count =  $result->rowcount();
                                                for($i=0; $rows = $result->fetch(); $i++)
                                                {
                                                echo '<option>'.$rows['district'].'</option>';
                                                }
                                            ?>	
                                        </datalist>  
                                </div>  
                                <div class="col-md-6">
                                    <label>Panchayath</label>
                                    <input list="panchayath" required class="form-control" name="panchayath">
                                        <datalist id="panchayath">
                                          <option value="">Select</option> 
											 <?php
                                           $result = $db->prepare("SELECT distinct(panchayath) FROM disaster");
                                                $result->execute();
                                                $row_count =  $result->rowcount();
                                                for($i=0; $rows = $result->fetch(); $i++)
                                                {
                                                echo '<option>'.$rows['panchayath'].'</option>';
                                                }
                                            ?>	
                                        </datalist>        
                                </div>  
                            </div>  
                            <div class="row">
                              <div class="col-md-6">
                                  <label>Village</label>
                                  <input list="village" required class="form-control" name="village">
                                      <datalist id="village">
                                    <option value="">Select</option> 
                                     <?php
								   $result = $db->prepare("SELECT distinct(village) FROM disaster");
										$result->execute();
										$row_count =  $result->rowcount();
										for($i=0; $rows = $result->fetch(); $i++)
										{
										echo '<option>'.$rows['village'].'</option>';
										}
									?>	
                                </datalist> 
                              </div>
                              <div class="col-md-6">
                                  <label>Location</label>
                                  <input type="text" class="form-control" name="location" required>        
                              </div>       
                            </div> 
                            <div class="row">                
                              <div class="col-md-6">
                                  <label>Officer Name</label>
                                  <input type="text" class="form-control" name="oname" required pattern="[a-zA-Z]*" >        
                              </div>
                              <div class="col-md-6">
                                  <label>Date</label>
                                  <input type="date" class="form-control" name="date" required max="<?php echo date("Y-m-d");?>">        
                              </div>  
                            </div>
                            <div class="row">                    
                              <div class="col-md-6">
                                  <label>Photo</label>
                                  <input type="file" class="form-control" name="photo1" required accept=".png, .jpg, .jpeg">        
                              </div>
                              <div class="col-md-6">
                                  <label>Photo</label>
                                  <input type="file" class="form-control" name="photo2" required accept=".png, .jpg, .jpeg">        
                              </div>
                            </div>
                            <div class="row">
                              <div class="col-md-6">
                                  <label>Description</label>
                                  <textarea name="desp" class="form-control" required rows="3"></textarea>
                              </div>   
                              <div class="col-md-6">
                                  <label>Map</label>
                                  <textarea name="map" class="form-control" required rows="3"></textarea>
                              </div> 
                            </div>                                                                            
                              <div class="col-xs-12 ">
                                      <br>
                                      <input type="submit" value="Submit" class="btn btn-danger text-white" style="float: right;">
                                  </div>
                          </form>
                        </div>
                    </div>
                </div>
                <!-- New End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_ADMIN_ID'];
	$result = $db->prepare("select * from admin where Log_Id='$Log_Id'");
	$result->execute();
	for ($i = 0; $row = $result->fetch(); $i++) 
	{
			
		$photo= $row['photo'];
	}
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <?php 
				$result = $db->prepare("select * from disaster");
				$result->execute();
				for ($i = 0; $row = $result->fetch(); $i++) 
				{
				?>
                <div class="col-12 grid-margin stretch-card d-none d-md-flex">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Land Slide  / Any Disaster Place</h4>
                      <hr>
                      <div class="row">
                        
                        <div class="col-3">
                          <ul class="nav nav-tabs nav-tabs-vertical-custom" role="tablist" style="background-color:brown;">
                            <li class="nav-item">
                              <a class="nav-link active" id="profilea<?php echo $row["dis_id"];?>" data-bs-toggle="tab" href="#profile<?php echo $row["dis_id"];?>" role="tab" aria-controls="home-3" aria-selected="true">
                                Place 
                              </a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" id="complaintu<?php echo $row["dis_id"];?>" data-bs-toggle="tab" href="#complaintas<?php echo $row["dis_id"];?>" role="tab" aria-controls="home-3" aria-selected="false">
                              Contact
                              </a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" id="photoa<?php echo $row["dis_id"];?>" data-bs-toggle="tab" href="#photo<?php echo $row["dis_id"];?>" role="tab" aria-controls="contact-3" aria-selected="false">
                                Photos
                              </a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" id="videoa<?php echo $row["dis_id"];?>" data-bs-toggle="tab" href="#video<?php echo $row["dis_id"];?>" role="tab" aria-controls="contact-3" aria-selected="false">
                               Map
                              </a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" id="statusa<?php echo $row["dis_id"];?>" data-bs-toggle="tab" href="#status<?php echo $row["dis_id"];?>" role="tab" aria-controls="contact-3" aria-selected="false">
                               Message
                              </a>
                            </li>
                          </ul>
                        </div>
                        <div class="col-9 col-lg-9">
                          <div class="tab-content tab-content-vertical tab-content-vertical-custom">
                            <div class="tab-pane fade show active" id="profile<?php echo $row["dis_id"];?>" role="tabpanel" aria-labelledby="profilea<?php echo $row["dis_id"];?>">
                            <h5 class="mt-0 mb-1">Location Details</h5>
                                  <hr>
                            	<table class="table table-primary">
                                	<thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>District</th>
                                            <th>Panchyath</th>
                                            <th>Village</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    	<tr>
                                        	<td><?php echo $row["name"];?></td>
                                            <td><?php echo $row["district"];?></td>
                                            <td><?php echo $row["panchayath"];?></td>
                                            <td><?php echo $row["village"];?></td>
                                        </tr>
                                    </tbody>
                                </table>                    
                            </div>
                            <div class="tab-pane fade" id="complaintas<?php echo $row["dis_id"];?>" role="tabpanel" aria-labelledby="complaintu<?php echo $row["dis_id"];?>">
                              <div class="media">
                                <img class="align-self-center me-3 w-25 rounded" src="../photo/<?php echo $row["photo1"];?>" alt="sample image">
                                <div class="media-body">
                                <h5 class="mt-0 mb-1">Contact Details</h5>
                                  <hr>
                                  <table class="table table-info" style="width:500px;">
                                	<thead>
                                        <tr>
                                            <th>Officer</th>
                                            <th>Location</th>
                                            <th>Address</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    	<tr>
                                        	<td><?php echo $row["oname"];?></td>
                                            <td><?php echo $row["location"];?></td>
                                            <td><?php echo $row["addrs"];?></td>
                                            <td><?php echo $row["date"];?></td>
                                        </tr>
                                    </tbody>
                                </table> 
                                </div>
                              </div>
                            </div>
                            <div class="tab-pane fade" id="photo<?php echo $row["dis_id"];?>" role="tabpanel" aria-labelledby="photoa<?php echo $row["dis_id"];?>">
                              <div class="media">                              	
                                <img class="ms-3 w-25" style="width:500px;" src="../photo/<?php echo $row["photo1"];?>" alt="sample image">
                                <img class="ms-3 w-25" style="width:500px;" src="../photo/<?php echo $row["photo2"];?>" alt="sample image">
                              </div>
                            </div>
                            <div class="tab-pane fade" id="video<?php echo $row["dis_id"];?>" role="tabpanel" aria-labelledby="videoa<?php echo $row["dis_id"];?>">
                              <div class="media">
                                <div class="media-body">
                                <h5 class="mt-0 mb-1">Location Details</h5>
                                <hr>
                                 <iframe class="map" style="width:700px; height:350px;" src="https://maps.google.com/maps?q=<?php echo $row["map"];?>&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
                                </div>                                
                              </div>
                            </div>
                            <div class="tab-pane fade" id="status<?php echo $row["dis_id"];?>" role="tabpanel" aria-labelledby="statusa<?php echo $row["dis_id"];?>">
                              <div class="media">
                                <div class="media-body">
                                  <h5 class="mt-0 mb-1">Place Details</h5>
                                  <hr>
                                 <?php echo $row["desp"];?>
                                </div>                                
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- New End -->
            <?php }?>
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


`<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_VOL_ID'];
	
	$fdate=$_POST["fdate"];
	$tdate=$_POST["tdate"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <div class="col-lg-12">
                  <div class="card px-2">
                      <div class="card-body">
                          <div class="container-fluid">
                            <div class="row">
                              <div class="col-lg-6" style="float: left;">
                                <h3 class="text-start my-5">Report Missing People</h3>
                              </div>
                              <div class="col-lg-6">
                                <h3 class="text-end my-5">Form <?php echo $fdate;?> To <?php echo $tdate;?></h3>
                              </div>
                            </div>
                            
                            <hr>
                          </div>

                          <div class="container-fluid mt-5 d-flex justify-content-center w-100">
                            <div class="table-responsive w-100">
                                <table class="table">
                                  <thead>
                                    <tr class="bg-dark text-white">
                                        <th>#</th>
                                        <th>Aadhar</th>
                                        <th class="text-end">Name</th>
                                        <th class="text-end">Age</th>
                                        <th class="text-end">Gender</th>
                                        <th class="text-end">Address</th>
                                        <th class="text-end">District</th>
                                        <th class="text-end">Panchayath</th>
                                        <th class="text-end">Village</th>
                                        <th class="text-end">Ward</th>
                                        <th class="text-end">Officer</th>
                                        <th class="text-end">Location</th>
                                        <th class="text-end">Date</th>
                                        <th class="text-end">Status</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                  <?php
								  	$result = $db->prepare("select * from messing_people where date>='$fdate' and date<='$tdate'");
									$result->execute();
									for ($i = 1; $row = $result->fetch(); $i++) 
									{
								  ?>
                                    <tr class="text-end">
                                      <td class="text-start"><?php echo $i;?></td>
                                      <td class="text-start"><?php echo $row["aadhar"];?></td> 
                                      <td class="text-start"><?php echo $row["pname"];?></td>   
                                      <td class="text-start"><?php echo $row["age"];?></td>   
                                      <td class="text-start"><?php echo $row["sex"];?></td>   
                                      <td class="text-start"><?php echo $row["addrs"];?></td>   
                                      <td class="text-start"><?php echo $row["district"];?></td>  
                                      <td class="text-start"><?php echo $row["panchayath"];?></td>
                                      <td class="text-start"><?php echo $row["village"];?></td>
                                      <td class="text-start"><?php echo $row["ward"];?></td>     
                                      <td class="text-start"><?php echo $row["oname"];?></td>  
                                      <td class="text-start"><?php echo $row["location"];?></td>  
                                      <td class="text-start"><?php echo $row["date"];?></td>  
                                      <td class="text-start"><?php echo $row["status"];?></td>                                 
                                    </tr>  
                                   <?php }?>                                  
                                  </tbody>
                                </table>
                              </div>
                          </div>                          
                          <div class="container-fluid w-100" >
                            <a href="#" style="float: right;" class="btn btn-primary float-right mt-4 ms-2" onClick="window.print();"><i class="mdi mdi-printer me-1"></i>Print</a>
                         </div>
                      </div>
                  </div>
                <!--  End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


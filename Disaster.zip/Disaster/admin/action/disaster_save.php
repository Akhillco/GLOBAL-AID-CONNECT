<?php
include("../../connect/db.php");

	
	
	$name=$_POST["name"];
	$addrs=$_POST["addrs"];
	$district=$_POST["district"];
	$panchayath=$_POST["panchayath"];
	$village=$_POST["village"];
	$location=$_POST["location"];
	$oname=$_POST["oname"];
	$date=$_POST["date"];
	$map=$_POST["map"];
	$desp=$_POST["desp"];
	
	$image = addslashes(file_get_contents($_FILES['photo1']['tmp_name']));
	$image_name = addslashes($_FILES['photo1']['name']);
	$image_size = getimagesize($_FILES['photo1']['tmp_name']);
	move_uploaded_file($_FILES["photo1"]["tmp_name"], "../../photo/" . $_FILES["photo1"]["name"]);
	$photo1 = $_FILES["photo1"]["name"];
	
	$image = addslashes(file_get_contents($_FILES['photo2']['tmp_name']));
	$image_name = addslashes($_FILES['photo2']['name']);
	$image_size = getimagesize($_FILES['photo2']['tmp_name']);
	move_uploaded_file($_FILES["photo2"]["tmp_name"], "../../photo/" . $_FILES["photo2"]["name"]);
	$photo2 = $_FILES["photo2"]["name"];
	
	
$sql = "insert into disaster(name,addrs,district,panchayath,village,location,oname,date,photo1,photo2,desp,map)values('$name','$addrs','$district','$panchayath','$village','$location','$oname','$date','$photo1','$photo2','$desp','$map')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../disaster_search.php");
?>

`<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_DEPT_ID'];
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <div class="col-8 grid-margin">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">All Notification</h4>
                      <div class="row">
                        <div class="col-md-12 h-100">
                          <div class="bg-secondary p-4">
                            <div id="profile-list-left" class="py-2">
                              
                              <?php
							  	$result = $db->prepare("select * from  notification where Log_Id='$Log_Id'");
								$result->execute();
								for($i=1; $row = $result->fetch(); $i++)
									{
									$not_id = $row['not_id'];
							  ?>
                              <div class="card rounded mb-2">
                                <div class="card-body p-3">
                                  <div class="media">
                                    <img src="../photo/<?php echo $row["photo"];?>" alt="image" class="img-sm me-3 rounded-circle">
                                    <div class="media-body">
                                    	<table class="table table-danger">
                                        	<tr>
                                            	<th>Name</th>
                                                <th>Subject</th>
                                                <th>About</th>
                                                <th>Date</th>
                                                <th>Time</th>
                                            </tr>
                                            <tr>
                                            	<td><?php echo $row["name"];?></td>
                                                <td><?php echo $row["subj"];?></td>
                                                <td><?php echo $row["about"];?></td>
                                                <td><?php echo $row["date"];?></td>
                                                <td><?php echo $row["tm"];?></td>
                                            </tr>
                                        </table>
                                    </div>                              
                                  </div>
                                  <a href="action/notification_remove.php<?php echo '?not_id='.$not_id; ?>">
                                    <span class="mdi mdi-delete red" style="float: right; font-size:30px; color:red"></span>
                                  </a>    
                                </div>
                              </div>
                              <?php
									}
							  ?>
                              <?php
							  	$result = $db->prepare("select * from  notification where Log_Id!='$Log_Id'");
								$result->execute();
								for($i=1; $row = $result->fetch(); $i++)
									{
									$not_id = $row['not_id'];
							  ?>
                              <div class="card rounded mb-2">
                                <div class="card-body p-3">
                                  <div class="media">
                                    <img src="../photo/<?php echo $row["photo"];?>" alt="image" class="img-sm me-3 rounded-circle">
                                    <div class="media-body">
                                    	<table class="table table-danger">
                                        	<tr>
                                            	<th>Name</th>
                                                <th>Subject</th>
                                                <th>About</th>
                                                <th>Date</th>
                                                <th>Time</th>
                                            </tr>
                                            <tr>
                                            	<td><?php echo $row["name"];?></td>
                                                <td><?php echo $row["subj"];?></td>
                                                <td><?php echo $row["about"];?></td>
                                                <td><?php echo $row["date"];?></td>
                                                <td><?php echo $row["tm"];?></td>
                                            </tr>
                                        </table>
                                    </div>                              
                                  </div>                                    
                                </div>
                              </div>
                              <?php
									}
							  ?>
                            </div>
                          </div>
                        </div>
                        
                      </div>
                    </div>
                  </div>
             </div>
            
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


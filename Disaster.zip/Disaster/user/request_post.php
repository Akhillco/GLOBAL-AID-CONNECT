`<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_USER_ID'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <?php 
				$result = $db->prepare("select * from rquest_register where Log_Id='$Log_Id' and rstatus='Pending'");
				$result->execute();
				for ($i = 0; $row = $result->fetch(); $i++) 
				{
					$req_id=$row["req_id"];
			 ?>   
              <div class="col-12">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-lg-4">
                      <div class="border-bottom text-center pb-4">
                        <img src="../photo/<?php echo $row["photo"];?>" alt="profile" class="img-lg rounded-circle mb-3"/>
                        <div class="mb-3">
                          <h3><?php echo $row["name"];?></h3>
                        </div>
                        <p class="w-75 mx-auto mb-3"><?php echo $row["addr"];?> </p>
                        
                      </div>
                    </div>
                    <div class="col-lg-8">
                      <div class="d-block d-md-flex justify-content-between mt-4 mt-md-0">
                        <div class="text-center mt-4 mt-md-0">
                          <a href="#" class="btn btn-danger">Request</a>
                          <a href="#" class="btn btn-outline-primary"><?php echo $row["rstatus"];?></a>
                        </div>
                      </div>
                
                      <div class="profile-feed">
                        
                        <div class="d-flex align-items-start profile-feed-item">
                          <div class="col-lg-12">
                            <h6>
                              <table class="table">
                              	<tr>
                                	<th>Contact</th>
                                    <th>Subject</th>
                                    <th>From</th>
                                    <th>To</th>
                                    <th>Time</th>
                                    <th>Service</th>
                                </tr>
                                <tr>
                                	<td><?php echo $row["cntno"];?></td>
                                    <td><?php echo $row["subj"];?></td>
                                    <td><?php echo $row["fdate"];?></td>
                                    <td><?php echo $row["tdate"];?></td>
                                    <td><?php echo $row["ttime"];?></td>
                                    <td><?php echo $row["servce"];?></td>
                                </tr>
                              </table>
                          </div>
                        </div>
                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <?php }?>
                <!-- New End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


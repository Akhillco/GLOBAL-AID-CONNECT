<?php
include("../../connect/db.php");

	 $Log_Id="DST".rand(9874475896,1);

	 $departmnt=$_POST["departmnt"];
	 $name=$_POST["name"];
	 $cntno1=$_POST["cntno1"];
	 $cntno2=$_POST["cntno2"];
	 $addr=$_POST["addr"];
	 $email=$_POST["email"];
	 $username=$_POST["username"];
	 $password=$_POST["password"];
	 $about=$_POST["about"];
	 
	 $utype="Department";
	 $date=date("Y-m-d");
	
	$image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
	$image_name = addslashes($_FILES['photo']['name']);
	$image_size = getimagesize($_FILES['photo']['tmp_name']);
	move_uploaded_file($_FILES["photo"]["tmp_name"], "../../photo/" . $_FILES["photo"]["name"]);
	$photo = $_FILES["photo"]["name"];
	
	$sql = "insert into department(Log_Id,departmnt,name,cntno1,cntno2,addr,email,username,password,photo,about,utype,date)values('$Log_Id','$departmnt','$name','$cntno1','$cntno2','$addr','$email','$username','$password','$photo','$about','$utype','$date')";
	$q1 = $db->prepare($sql);
	$q1->execute();

	header("location:../department_search.php");
?>

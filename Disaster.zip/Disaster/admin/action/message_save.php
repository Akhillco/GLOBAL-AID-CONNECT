<?php
include("../../connect/db.php");

	$msg_id=$_POST["msg_id"];
	$reply=$_POST["reply"];
	
	$sstatus="clear";
	
	$date=date("d-m-Y");
	
	date_default_timezone_set('Asia/Kolkata');
	$tm = date( 'h:i:s A', time () );

	
$sql = "update message set rdate='$date',rtime='$tm',reply='$reply',sstatus='$sstatus' where msg_id='$msg_id'";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../message_view.php");
?>

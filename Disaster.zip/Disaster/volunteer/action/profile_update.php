<?php
include("../../connect/db.php");

	 $Log_Id=$_POST["Log_Id"];
	 $name=$_POST["name"];
	 $sex=$_POST["sex"];
	 $age=$_POST["age"];
	 $blgrp=$_POST["blgrp"];
	 $addrs=$_POST["addrs"];
	 $district=$_POST["district"];
	 $location=$_POST["location"];
	 $pinocde=$_POST["pinocde"];
	 $qulf=$_POST["qulf"];
	 $job=$_POST["job"];
	 $experincs=$_POST["experincs"];
	 $servce=$_POST["servce"];
	 $email=$_POST["email"];
	 $contactno=$_POST["contactno"];
	 $username=$_POST["username"];
	 $password=$_POST["password"];
	 

	$image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
	$image_name = addslashes($_FILES['photo']['name']);
	$image_size = getimagesize($_FILES['photo']['tmp_name']);
	move_uploaded_file($_FILES["photo"]["tmp_name"], "../../photo/" . $_FILES["photo"]["name"]);
	$photo = $_FILES["photo"]["name"];
	
	if($photo=="")
	{
		$sql = "update volunteer set name='$name',sex='$sex',age='$age',blgrp='$blgrp',addrs='$addrs',district='$district',location='$location',pinocde='$pinocde',qulf='$qulf',job='$job',experincs='$experincs',servce='$servce',email='$email',contactno='$contactno',username='$username',password='$password' where Log_Id='$Log_Id'";
		$q1 = $db->prepare($sql);
		$q1->execute();
	}
	else
	{
		$sql = "update volunteer set name='$name',sex='$sex',age='$age',blgrp='$blgrp',addrs='$addrs',district='$district',location='$location',pinocde='$pinocde',qulf='$qulf',job='$job',experincs='$experincs',servce='$servce',email='$email',contactno='$contactno',username='$username',password='$password',photo='$photo' where Log_Id='$Log_Id'";
		$q1 = $db->prepare($sql);
		$q1->execute();
	}
	header("location:../profile_settings.php");
?>

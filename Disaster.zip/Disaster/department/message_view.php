<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_DEPT_ID'];
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
   <link rel="stylesheet" href="vendors/datatables.net-bs4/dataTables.bootstrap4.css">
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">All Messages</h4>
                    <div class="row">
                      <div class="col-12">
                        <div class="table-responsive">
                          <table id="order-listing" class="table">
                            <thead>
                              <tr>
                                  <th>Sl No</th>
                                  <th>Subject</th>
                                  <th>Message</th>
                                  <th>Date</th>
                                  <th>Time</th>
                                  <th>Status</th>
                                  <th>Reply</th>
                              </tr>
                            </thead>
                            <tbody>
                            <?php
								$result = $db->prepare("select * from message where  sstatus='Pending'");
								$result->execute();
								for ($i = 1; $row = $result->fetch(); $i++) 
								{
							?>
                              <tr>
                                  <td><?php echo $i;?></td>
                                  <td><?php echo $row["subj"];?></td>
                                  <td><?php echo $row["about"];?></td>
                                  <td><?php echo $row["sdate"];?></td>
                                  <td><?php echo $row["stime"];?></td>
                                  <td>
                                    <label class="badge badge-danger"><?php echo $row["sstatus"];?></label>
                                  </td>
                                 <td>
                          			<a href="message_send.php<?php echo '?msg_id='.$row["msg_id"];?>" class="btn btn-outline-info">Reply</a>
                                 </td>
                              </tr>
                             <?php }?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                <!-- New End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
   <script src="vendors/datatables.net/jquery.dataTables.js"></script>
   <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
   <script src="js/data-table.js"></script>
</body>

</html>


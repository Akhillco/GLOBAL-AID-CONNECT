<?php
	$result = $db->prepare("select * from people where Log_Id='$Log_Id'");
	$result->execute();
	for ($i = 0; $row = $result->fetch(); $i++) 
	{
		$sheadname= $row['name'];
		$sheadphoto= $row['photo'];
	}
?>
<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
      <center>
      <a class="nav-link" href="index.php">
         <img src="../photo/<?php echo $sheadphoto;?>" class="img-lg rounded-circle mb-2">
      </a>
      </center>
      <li class="nav-item">
        <a class="nav-link" href="index.php">
          <i class="mdi mdi-view-quilt menu-icon"></i>
          <span class="menu-title">Dashboard</span>
          <div class="badge badge-info badge-pill"></div>
        </a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="collapse" href="#department" aria-expanded="false" aria-controls="ui-basic">
          <i class="mdi mdi-palette menu-icon"></i>
          <span class="menu-title">Department</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="department">
          <ul class="nav flex-column sub-menu">
             <li class="nav-item"> <a class="nav-link" href="department_search.php"> View</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="collapse" href="#emegcyreq" aria-expanded="false" aria-controls="form-elements">
          <i class="mdi mdi-view-headline menu-icon"></i>
          <span class="menu-title">Emergency</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="emegcyreq">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item"><a class="nav-link" href="em_request.php"> Request</a></li>
            <li class="nav-item"><a class="nav-link" href="em_request_confirm.php"> Accept</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="collapse" href="#helpline" aria-expanded="false" aria-controls="form-elements">
          <i class="mdi mdi-view-headline menu-icon"></i>
          <span class="menu-title">Helpline</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="helpline">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item"><a class="nav-link" href="helpline_search.php"> Search</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="collapse" href="#missing" aria-expanded="false" aria-controls="editors">
          <i class="mdi mdi-pencil-box-outline menu-icon"></i>
          <span class="menu-title">Missing</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="missing">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item"><a class="nav-link" href="missing_people_search.php"> View</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="collapse" href="#request" aria-expanded="false" aria-controls="charts">
          <i class="mdi mdi-chart-pie menu-icon"></i>
          <span class="menu-title">Request</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="request">
         <ul class="nav flex-column sub-menu">
            <li class="nav-item"> <a class="nav-link" href="request_register.php" > Register</a></li>
            <li class="nav-item"> <a class="nav-link" href="request_post.php"> Post</a></li>
            <li class="nav-item"> <a class="nav-link" href="request_request.php"> Request</a></li>
            <li class="nav-item"> <a class="nav-link" href="request_confirm.php"> Confirm</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="collapse" href="#complaint" aria-expanded="false" aria-controls="tables">
          <i class="mdi mdi-grid-large menu-icon"></i>
          <span class="menu-title">Complaint</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="complaint">
          <ul class="nav flex-column sub-menu">
             <li class="nav-item"> <a class="nav-link" href="complaint_register.php"> Register  </a></li>
             <li class="nav-item"> <a class="nav-link" href="complanit_pending.php"> Pending</a></li>
             <li class="nav-item"> <a class="nav-link" href="complanit_forward.php"> Forward</a></li>
             <li class="nav-item"> <a class="nav-link" href="complanit_clear.php"> Clear</a></li>
             <li class="nav-item"> <a class="nav-link" href="complanit_cancel.php"> Cancel</a></li>
          </ul>
        </div>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="collapse" href="#camp" aria-expanded="false" aria-controls="icons">
          <i class="mdi mdi-emoticon menu-icon"></i>
          <span class="menu-title">Camp</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="camp">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item"> <a class="nav-link" href="camp_search.php">Search</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="collapse" href="#funds" aria-expanded="false" aria-controls="maps">
          <i class="mdi mdi-map menu-icon"></i>
          <span class="menu-title">Funds</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="funds">
          <ul class="nav flex-column sub-menu">
           <li class="nav-item"> <a class="nav-link" href="funds_issued.php"> Search</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="collapse" href="#disaster" aria-expanded="false" aria-controls="auth">
          <i class="mdi mdi-map menu-icon"></i>
          <span class="menu-title">Disaster Place</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="disaster">
          <ul class="nav flex-column sub-menu">
             <li class="nav-item"> <a class="nav-link" href="disaster_search.php"> Search </a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="collapse" href="#report" aria-expanded="false" aria-controls="error">
          <i class="mdi mdi-alert-circle menu-icon"></i>
          <span class="menu-title">Report</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="report">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item"> <a class="nav-link" href="report_complaint.php"> Complaint </a></li>
            <li class="nav-item"> <a class="nav-link" href="report_funds.php"> Funds </a></li>
            <li class="nav-item"> <a class="nav-link" href="report_missing.php"> Missing </a></li>
            <li class="nav-item"> <a class="nav-link" href="report_disaster.php"> Disaster </a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="collapse" href="#noti" aria-expanded="false" aria-controls="general-pages">
          <i class="mdi mdi-email menu-icon"></i>
          <span class="menu-title">Notification</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="noti">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item"> <a class="nav-link" href="notification_send.php"> Send</a></li>
            <li class="nav-item"> <a class="nav-link" href="notification_search.php"> View </a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="collapse" href="#message" aria-expanded="false" aria-controls="e-commerce">
          <i class="mdi mdi-file-document menu-icon"></i>
          <span class="menu-title">Message</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="message">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item"> <a class="nav-link" href="message_send.php"> Send </a></li>
            <li class="nav-item"> <a class="nav-link" href="message_view.php"> View </a></li>
            <li class="nav-item"> <a class="nav-link" href="message_reply.php"> Reply </a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item sidebar-category">
        <p>Logout</p>
        <span></span>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="../index.php">
          <i class="mdi mdi-logout menu-icon"></i>
          <span class="menu-title">Logout</span>
        </a>
      </li>
      
    </ul>
  </nav>
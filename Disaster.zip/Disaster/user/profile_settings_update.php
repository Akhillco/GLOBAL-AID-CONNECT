<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_USER_ID'];
	$result = $db->prepare("select * from people where Log_Id='$Log_Id'");
	$result->execute();
	for ($i = 0; $row = $result->fetch(); $i++) 
	{
		 $name=$row["name"];
		 $sex=$row["sex"];
		 $age=$row["age"];
		 $blgrp=$row["blgrp"];
		 $addrs=$row["addrs"];
		 $district=$row["district"];
		 $location=$row["location"];
		 $pinocde=$row["pinocde"];
		 $email=$row["email"];
		 $contactno=$row["contactno"];
		 $username=$row["username"];
		 $password=$row["password"];
		 $photo=$row["photo"];
	}
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <div class="col-md-9 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title alert alert-info">Profile Update</h4>
                           
                            <form method="post" action="action/profile_update.php" class="forms" autocomplete="off" enctype="multipart/form-data">   
                            <div class="row">
                              <div class="col-md-6">
                                    <label>Name</label>
                                    <input type="hidden"  name="Log_Id"  value="<?php echo $Log_Id;?>">    
                                    <input type="text"  name="name" class="form-control" value="<?php echo $name;?>" required pattern="[a-zA-Z]*">             
                                </div>                          
                                <div class="col-md-6">
                                    <label>Age</label>
                                      <input type="text"  name="age" class="form-control" value="<?php echo $age;?>" min="18" max="100" required>
                                </div>
                            </div>  
                            <div class="row">
                              <div class="col-md-6">
                                    <label>Gender</label>
                                    <select name="sex" class="form-control" style="height:50px; color:black;" required>
                                    	<option><?php echo $sex;?></option>
                                        <option>Male</option>
                                        <option>Female</option>
                                        <option>Transgender</option>
                                    </select>          
                                </div>                          
                                <div class="col-md-6">
                                    <label>Location</label>
                                      <input type="text"  name="location" class="form-control" value="<?php echo $location;?>" required>
                                </div>
                            </div>                            
                            <div class="row">
                              <div class="col-md-12">
                                  <label>Address</label>
                                 <input type="text"  name="addrs" class="form-control" value="<?php echo $addrs;?>" required>
                              </div>
                              <div class="col-md-6">
                                  <label>District</label>
                                  <input type="text" class="form-control" name="district" value="<?php echo $district;?>" required>        
                              </div>   
                               <div class="col-md-6">
                                  <label>Pincode</label>
                                  <input type="text" class="form-control" name="pinocde" value="<?php echo $pinocde;?>" required pattern="[0-9]{6,6}" maxlength="6" minlength="6" >        
                              </div>    
                            </div> 
                          
                            <div class="row">                
                              <div class="col-md-6">
                                  <label>Email</label>
                                  <input type="text" class="form-control" name="email" value="<?php echo $email;?>" required>        
                              </div>
                              <div class="col-md-6">
                                  <label>Contact No</label>
                                  <input type="password" class="form-control" name="contactno" value="<?php echo $contactno;?>" required pattern="[0-9]{10,10}" maxlength="10" minlength="10" >        
                              </div>  
                            </div>
                            <div class="row">                
                              <div class="col-md-6">
                                  <label>Blood Group</label>
                                 <select class="form-control" name="blgrp" style="height:50px; color:black;" required>
                                 	<option><?php echo $blgrp?></option>
                                    <option>A+</option>
                                    <option>A</option>
                                    <option>B+</option>
                                 </select>
                              </div>
                              <div class="col-md-6">
                                  <label>Photo</label>
                                  <input type="file" class="form-control" name="photo" accept=".png, .jpg, .jpeg">        
                              </div>  
                            </div>
                              <div class="row">                
                              <div class="col-md-6">
                                  <label>Username</label>
                                  <input type="text" class="form-control" name="username" value="<?php echo $username;?>" required minlength="4" maxlength="15">        
                              </div>
                              <div class="col-md-6">
                                  <label>Password</label>
                                  <input type="password" class="form-control" name="password" value="<?php echo $password;?>" required minlength="4" maxlength="15">        
                              </div>  
                            </div>
                           
                            </div>                                                                            
                              <div class="col-xs-12 ">
                                      <br>
                                      <input type="submit" value="Update" class="btn btn-primary text-white" style="float: right;">
                                  </div>
                          </form>
                        </div>
                    </div>
                </div>
                <!-- New End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


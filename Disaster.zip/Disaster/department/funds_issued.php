`<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_DEPT_ID'];
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
          
            <div class="row">
                <!-- New Request -->
                <?php
			$result = $db->prepare("select * from funds");
			$result->execute();
			for($i=0; $rows = $result->fetch(); $i++)
			{
				?>
                <div class="col-12">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-lg-4">
                      <div class="border-bottom text-center pb-4">
                        <img src="../photo/<?php echo $rows["iphoto"];?>" alt="profile" class="img-lg rounded-circle mb-3"/>
                        <div class="mb-3">
                          <h3><?php echo $rows["people"];?></h3>
                        </div>
                        <p class="w-75 mx-auto mb-3"><?php echo $rows["addrs"];?> </p>
                        
                      </div>
                    </div>
                    <div class="col-lg-8">
                      <div class="d-block d-md-flex justify-content-between mt-4 mt-md-0">
                          <label class="alert alert-danger col-ms-12" style="width: 100%;">Status <?php echo "Issued";?></label>
                      </div>
                
                      <div class="profile-feed">
                        
                        <div class="d-flex align-items-start profile-feed-item">
                            <h6>
                             <table class="table table-primary" style="width:660px">
                                <thead>
                                    <tr>
                                        <th>Bank</th>
                                        <th>Amount</th>
                                        <th>Issue</th>
                                        <th>Complaint Date</th>
                                        <th>Issue Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo $rows["bank"];?></td>
                                        <td><?php echo $rows["amnt"];?></td>
                                        <td><?php echo $rows["issun"];?></td>
                                        <td><?php echo $rows["fdate"];?></td>
                                        <td><?php echo $rows["idate"];?></td>
                                    </tr>
                                </tbody>
                            </table> 
                          </div>
                        </div>
                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>
                <!-- New End -->
            <?php }?>
            </div>
        
        </div>
        
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


<?php
include('../../connect/db.php');


	$pname=$_POST["pname"]; 	
	$status=$_POST["status"]; 	
	$desp=$_POST["desp"]; 	
	
	
$sql = "update messing_people set status='$status',desp='$desp' where pname='$pname'";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../missing_people_search.php");

?>						

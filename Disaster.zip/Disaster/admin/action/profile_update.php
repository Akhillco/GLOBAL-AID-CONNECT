<?php
	include("../auth.php");
	include('../../connect/db.php');
	$Log_Id = $_SESSION['SESS_ADMIN_ID'];

	$name=$_POST["name"];
	$location=$_POST["location"];
	$addrs=$_POST["addrs"];
	$contact=$_POST["contact"];
	$email=$_POST["email"];
	$about=$_POST["about"];
	$username=$_POST["username"];
	$password=$_POST["password"];
	$offname=$_POST["offname"];
	$edate=$_POST["edate"];
	
	$image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
	$image_name = addslashes($_FILES['photo']['name']);
	$image_size = getimagesize($_FILES['photo']['tmp_name']);
	move_uploaded_file($_FILES["photo"]["tmp_name"], "../../photo/" . $_FILES["photo"]["name"]);
	$photo = $_FILES["photo"]["name"];
	
	
	if($photo=="")
	{
		$sql = "update admin set name='$name',location='$location',addrs='$addrs',contact='$contact',email='$email',about='$about',username='$username',password='$password',offname='$offname',edate='$edate' where Log_Id='$Log_Id'";
		$q1 = $db->prepare($sql);
		$q1->execute();
	}
	else
	{
		$sql = "update admin set name='$name',location='$location',addrs='$addrs',contact='$contact',email='$email',photo='$photo',about='$about',username='$username',password='$password',offname='$offname',edate='$edate' where Log_Id='$Log_Id'";
		$q1 = $db->prepare($sql);
		$q1->execute();
	}
	header("location:../profile_settings.php");
?>

<?php
	//Start session
	session_start();
	include("connect/db.php");
	//Sanitize the POST values
	$email = $_POST['email'];
	$password = $_POST['password'];
	//Create query
	$qryadmin = $db->prepare("SELECT * FROM admin WHERE username='$email' and password='$password' and utype='Admin'");
	$qryadmin->execute();
	$countadmin = $qryadmin->rowcount();
	
	
	$qrydprt = $db->prepare("SELECT * FROM department WHERE username='$email' and password='$password' and utype='Department'");
	$qrydprt->execute();
	$countdprt = $qrydprt->rowcount();
	
	$qryvolntr = $db->prepare("SELECT * FROM volunteer WHERE username='$email' and password='$password' and utype='Volunteer' and stat='Active'");
	$qryvolntr->execute();
	$countvolntr= $qryvolntr->rowcount();
	
	$qryusr = $db->prepare("SELECT * FROM people WHERE username='$email' and password='$password' and utype='People' and stat='Active'");
	$qryusr->execute();
	$countusr = $qryusr->rowcount();
	
	//Check whether the query was successful or not
	if($countadmin > 0) {
		//Login Successful
		session_regenerate_id();
		$rowsadmin = $qryadmin->fetch();
		$_SESSION['SESS_ADMIN_ID'] = $rowsadmin['Log_Id'];
		session_write_close();
		header("location:admin/index.php");
		exit();
	}
	
	else if($countdprt > 0) {
		//Login Successful
		session_regenerate_id();
		$rowdprt = $qrydprt->fetch();
		$_SESSION['SESS_DEPT_ID'] = $rowdprt['Log_Id'];
		session_write_close();
		header("location:department/index.php");
		exit();
	}
	else if($countvolntr > 0) {
		//Login Successful
		session_regenerate_id();
		$rowvolntr = $qryvolntr->fetch();
		$_SESSION['SESS_VOL_ID'] = $rowvolntr['Log_Id'];
		session_write_close();
		header("location:volunteer/index.php");
		exit();
	}
	else if($countusr > 0) {
		//Login Successful
		session_regenerate_id();
		$rowusr = $qryusr->fetch();
		$_SESSION['SESS_USER_ID'] = $rowusr['Log_Id'];
		session_write_close();
		header("location:user/index.php");
		exit();
	}
	else 
	{
		//Login failed
		echo "<script>alert('Check Username And Password.'); window.location='login.php'</script>";
		exit();
	}
?>

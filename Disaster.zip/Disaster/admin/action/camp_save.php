<?php
include("../../connect/db.php");

	$Log_Id=$_POST["Log_Id"];	
	$photo=$_POST["photo"];	
	$departmnt=$_POST["departmnt"];	
	$iname=$_POST["iname"];	
	$cntno=$_POST["cntno"];	
	$fdate=$_POST["fdate"];
	$tdate=$_POST["tdate"];	
	$time=$_POST["time"];	
	$addrs=$_POST["addrs"];	
	$cdescp=$_POST["cdescp"];	
	
$sql = "insert into camp(Log_Id,photo,departmnt,iname,cntno,fdate,tdate,time,addrs,cdescp)values('$Log_Id','$photo','$departmnt','$iname','$cntno','$fdate','$tdate','$time','$addrs','$cdescp')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../camp_search.php");
?>

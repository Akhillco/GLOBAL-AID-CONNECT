<?php
include('../../connect/db.php');


	$cmp_id=$_POST["cmp_id"]; 	
	$status=$_POST["status"]; 	
	$descp=$_POST["descp"]; 	
	
	
$sql = "update complaints set aststus='$status',descp='$descp' where cmp_id='$cmp_id'";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../complanit_forward.php");

?>						

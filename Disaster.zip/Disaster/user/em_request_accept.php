<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_USER_ID'];
	$result = $db->prepare("select * from people where Log_Id='$Log_Id'");
	$result->execute();
	for ($i = 0; $row = $result->fetch(); $i++) 
	{
		 $name=$row["name"];
		 $addr=$row["addrs"];
		 $contactno=$row["contactno"];
	}
  $req_id=$_GET["req_id"];	
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <div class="col-md-9 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title alert alert-info">Request Accept</h4>
                           
                            <form method="get" action="action/em_request_accept.php" class="forms" autocomplete="off" enctype="multipart/form-data">                           
                                <div class="row">
                                  <div class="col-md-6">
                                      <label>Name</label>
                                          <input type="text"  name="name" class="form-control" readonly value="<?php echo $name;?>">   
                                          <input type="hidden"  name="Log_Id" value="<?php echo $Log_Id;?>">    
                                          <input type="hidden"  name="req_id" value="<?php echo $req_id;?>">    
                                                       
                                  </div> 
                                  <div class="col-md-6">
                                      <label>Contact No</label>
                                          <input type="text"  name="cntno" class="form-control"  readonly value="<?php echo $contactno;?>">                
                                  </div>
                                </div>
                                <div class="row">                         
                                  <div class="col-md-12">
                                      <label>Address</label>
                                          <input type="text"  name="addr" class="form-control"  readonly value="<?php echo $addr;?>">                 
                                  </div>  
                                </div>
                                <div class="row">
                                  <div class="col-md-6">
                                      <label>Quantity</label>
                                          <input type="number"  name="qty" class="form-control" required min="0">                 
                                  </div>   
                                  <div class="col-md-6">
                                      <label>Date</label>
                                          <input type="date"  name="tdate" class="form-control" readonly value="<?php echo date("Y-m-d");?>">                
                                  </div>
                                </div> 
                                                                                          
                                <div class="col-xs-12 text-right">
                                        <br>
                                        <input type="submit" value="Submit" class="btn float-right btn-primary" style="float: right;">
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- New End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 20, 2025 at 01:51 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `disaster`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `Log_Id` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `addrs` text NOT NULL,
  `contact` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `photo` text NOT NULL,
  `about` text NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `utype` varchar(100) NOT NULL,
  `offname` varchar(200) NOT NULL,
  `edate` date NOT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `Log_Id`, `name`, `location`, `addrs`, `contact`, `email`, `photo`, `about`, `username`, `password`, `utype`, `offname`, `edate`) VALUES
(1, 'DS12444656HDHD', 'Kerala Govt', 'TVM', 'Thrivanadhapuram', '9847169014', 'dias@gmail.com', 'chrysanthemum - Copy.jpg', 'On the Insert tab, the galleries include items that are designed to coordinate with the overall look of your document. You can use these galleries to insert tables, headers, footers, lists, cover pages, and ', 'admin@gmail.com', 'admin', 'admin', 'Raj', '2025-01-12');

-- --------------------------------------------------------

--
-- Table structure for table `camp`
--

CREATE TABLE IF NOT EXISTS `camp` (
  `camp_id` int(11) NOT NULL AUTO_INCREMENT,
  `Log_Id` varchar(200) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `departmnt` varchar(200) NOT NULL,
  `iname` varchar(200) NOT NULL,
  `cntno` varchar(200) NOT NULL,
  `fdate` date NOT NULL,
  `tdate` date NOT NULL,
  `time` varchar(200) NOT NULL,
  `addrs` text NOT NULL,
  `cdescp` text NOT NULL,
  PRIMARY KEY (`camp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `camp`
--

INSERT INTO `camp` (`camp_id`, `Log_Id`, `photo`, `departmnt`, `iname`, `cntno`, `fdate`, `tdate`, `time`, `addrs`, `cdescp`) VALUES
(2, 'DS12444656HDHD', 'chrysanthemum - Copy.jpg', 'KSEB', 'Sham', '7779797979', '2025-01-13', '2025-01-16', '07:39', 'PKD', 'NICE'),
(3, 'DS12444656HDHD', 'chrysanthemum - Copy.jpg', 'KSEB', 'Sham', '7779797979', '2025-01-13', '2025-01-16', '07:39', 'PKD', 'NICE'),
(4, 'DST812324980', 'chrysanthemum.jpg', 'KSEB', 'Sham', '7979797979', '2025-12-31', '2025-12-30', '12:59', 'Palakkad', 'safasasf'),
(5, 'DS12444656HDHD98765', 'b.jpg', 'Rasi', 'safasf', '3552352352', '2025-01-09', '2025-01-24', '07:43', 'asfasf', 'asfasfasf');

-- --------------------------------------------------------

--
-- Table structure for table `camp_request`
--

CREATE TABLE IF NOT EXISTS `camp_request` (
  `camp_req_id` int(11) NOT NULL AUTO_INCREMENT,
  `cdepartment` text NOT NULL,
  `cname` text NOT NULL,
  `ccntno` text NOT NULL,
  `cdate` text NOT NULL,
  `uname` text NOT NULL,
  `usex` text NOT NULL,
  `uage` text NOT NULL,
  `udistrict` text NOT NULL,
  `uemail` text NOT NULL,
  `ucontact` text NOT NULL,
  `ustat` text NOT NULL,
  `udate` text NOT NULL,
  PRIMARY KEY (`camp_req_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE IF NOT EXISTS `complaints` (
  `cmp_id` int(11) NOT NULL AUTO_INCREMENT,
  `Log_Id` varchar(200) NOT NULL,
  `departmnt` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `aadharno` varchar(200) NOT NULL,
  `age` varchar(200) NOT NULL,
  `sex` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `wrd` varchar(200) NOT NULL,
  `panchayath` varchar(200) NOT NULL,
  `village` varchar(200) NOT NULL,
  `thaluk` varchar(200) NOT NULL,
  `distict` varchar(200) NOT NULL,
  `pstation` varchar(200) NOT NULL,
  `contactno1` varchar(200) NOT NULL,
  `contactno2` varchar(200) NOT NULL,
  `addrs` text NOT NULL,
  `photo` text NOT NULL,
  `video` text NOT NULL,
  `compl` text NOT NULL,
  `ddate` date NOT NULL,
  `lphoto` text NOT NULL,
  `dstatus` varchar(200) NOT NULL,
  `aststus` varchar(200) NOT NULL,
  `descp` text NOT NULL,
  PRIMARY KEY (`cmp_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`cmp_id`, `Log_Id`, `departmnt`, `name`, `aadharno`, `age`, `sex`, `email`, `wrd`, `panchayath`, `village`, `thaluk`, `distict`, `pstation`, `contactno1`, `contactno2`, `addrs`, `photo`, `video`, `compl`, `ddate`, `lphoto`, `dstatus`, `aststus`, `descp`) VALUES
(1, 'DS12444656HDHD987', 'KSEB', 'Sham', '235235235235', '20', 'Male', 'sham@gmail.com', '3', 'Kottauyi', 'Kottauyi', 'Kottauyi', 'Kottauyi', 'Kottauyi', '9847169014', '3235235235', 'Palakakd', 'Desert.jpg', 'sample.mp4', 'q', '2025-01-10', 'Desert.jpg', 'issue', 'Clear', 'sgsdgsdg'),
(2, 'DS12444656HDHD987', 'KSEB', 'Raj', '235235235235', '20', 'Male', 'sham@gmail.com', '3', 'Kottauyi', 'Kottauyi', 'Kottauyi', 'Kottauyi', 'Kottauyi', '9847169014', '3235235235', 'Palakakd', 'Desert.jpg', 'sample.mp4', 'q', '2025-01-10', 'Desert.jpg', 'Pending', 'Cancel', ''),
(3, 'DS12444656HDHD987', 'KSEB', 'Ram', '235235235235', '20', 'Male', 'sham@gmail.com', '3', 'Kottauyi', 'Kottauyi', 'Kottauyi', 'Kottauyi', 'Kottauyi', '9847169014', '3235235235', 'Palakakd', 'Desert.jpg', 'sample.mp4', 'q', '2025-01-10', 'Desert.jpg', 'Pending', 'Forward', 'asfasf'),
(4, 'DS12444656HDHD987', 'KSEB', 'Rani', '235235235235', '20', 'Male', 'sham@gmail.com', '3', 'Kottauyi', 'Kottauyi', 'Kottauyi', 'Kottauyi', 'Kottauyi', '9847169014', '3235235235', 'Palakakd', 'Desert.jpg', 'sample.mp4', 'q', '2025-01-10', 'Desert.jpg', 'Pending', 'Pending', '');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `dep_id` int(11) NOT NULL AUTO_INCREMENT,
  `Log_Id` varchar(200) NOT NULL,
  `departmnt` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `cntno1` varchar(200) NOT NULL,
  `cntno2` varchar(200) NOT NULL,
  `addr` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `photo` text NOT NULL,
  `about` text NOT NULL,
  `utype` varchar(200) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`dep_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dep_id`, `Log_Id`, `departmnt`, `name`, `cntno1`, `cntno2`, `addr`, `email`, `username`, `password`, `photo`, `about`, `utype`, `date`) VALUES
(2, 'DST812324980', 'KSEB', 'Sham', '7979797979', '6464646464', 'palakkad', 'pal@gmail.com', 'kseb@gmail.com', '123456', 'chrysanthemum.jpg', 'On the Insert tab, the galleries include items that are designed to coordinate with the overall look of your document. You can use these galleries to insert tables, headers, footers, lists, cover pages, and ', 'Department', '2025-01-12'),
(3, 'DST282639898', 'WATER', 'Sham', '7979797979', '6464646464', 'palakkad', 'pal@gmail.com', 'water', 'water', 'b.jpg', 'On the Insert tab, the galleries include items that are designed to coordinate with the overall look of your document. You can use these galleries to insert tables, headers, footers, lists, cover pages, and ', 'Department', '2025-01-12');

-- --------------------------------------------------------

--
-- Table structure for table `disaster`
--

CREATE TABLE IF NOT EXISTS `disaster` (
  `dis_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `addrs` text NOT NULL,
  `district` varchar(200) NOT NULL,
  `panchayath` varchar(200) NOT NULL,
  `village` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `oname` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `photo1` text NOT NULL,
  `photo2` text NOT NULL,
  `desp` text NOT NULL,
  `map` text NOT NULL,
  PRIMARY KEY (`dis_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `disaster`
--

INSERT INTO `disaster` (`dis_id`, `name`, `addrs`, `district`, `panchayath`, `village`, `location`, `oname`, `date`, `photo1`, `photo2`, `desp`, `map`) VALUES
(1, 'Kottayi', 'Palakakd', 'Palakkad', 'Palakkad', 'Palakkad', 'Palakkad', 'Raj', '2025-01-08', 'a.jpg', '10072017_1499703971_711060.jpg', 'Palakkad', 'Palakkad,Kottayi,Kariyankode'),
(2, 'Kottayi', 'Palakakd', 'Palakkad', 'Palakkad', 'Palakkad', 'Palakkad', 'Raj', '2025-01-08', 'a.jpg', '10072017_1499703971_711060.jpg', 'Palakkad', 'Palakkad,Kottayi,Kariyankode');

-- --------------------------------------------------------

--
-- Table structure for table `donate`
--

CREATE TABLE IF NOT EXISTS `donate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `phone` text NOT NULL,
  `email` text NOT NULL,
  `donate` text NOT NULL,
  `descp` text NOT NULL,
  `dated` text NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `emergency`
--

CREATE TABLE IF NOT EXISTS `emergency` (
  `emerg_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `contno1` text NOT NULL,
  `contno2` text NOT NULL,
  `neds` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`emerg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `funds`
--

CREATE TABLE IF NOT EXISTS `funds` (
  `fun_id` int(11) NOT NULL AUTO_INCREMENT,
  `people` varchar(200) NOT NULL,
  `sex` varchar(200) NOT NULL,
  `age` varchar(200) NOT NULL,
  `addrs` varchar(200) NOT NULL,
  `aadharno` varchar(200) NOT NULL,
  `district` varchar(200) NOT NULL,
  `panchayath` varchar(200) NOT NULL,
  `village` varchar(200) NOT NULL,
  `bank` varchar(200) NOT NULL,
  `accno` varchar(200) NOT NULL,
  `amnt` varchar(200) NOT NULL,
  `issun` varchar(200) NOT NULL,
  `offname` varchar(200) NOT NULL,
  `fdate` date NOT NULL,
  `idate` date NOT NULL,
  `iphoto` text NOT NULL,
  `photo` text NOT NULL,
  `desp` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`fun_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `funds`
--

INSERT INTO `funds` (`fun_id`, `people`, `sex`, `age`, `addrs`, `aadharno`, `district`, `panchayath`, `village`, `bank`, `accno`, `amnt`, `issun`, `offname`, `fdate`, `idate`, `iphoto`, `photo`, `desp`, `date`) VALUES
(1, 'Sham', 'Male', '20', 'Palakakd', '235235235235', 'Palakkad', 'Kottayi', 'Kottayi', 'IHHH', '85797979', '45000', '60000', 'Ofii', '2025-01-10', '2025-01-24', 'a.jpg', 'Desert.jpg', 'asfasfasf', '2025-01-18'),
(2, 'Sham', 'Male', '20', 'Palakakd', '235235235235', 'Palakkad', 'Kottayi', 'Kottayi', 'IHHH', '85797979', '45000', '60000', 'Ofii', '2025-01-10', '2025-01-24', 'a.jpg', 'Desert.jpg', 'asfasfasf', '2025-01-18'),
(3, 'Sham', 'Male', '20', 'Palakakd', '235235235235', 'Palakkad', 'Kottayi', 'Kottayi', 'IHHH', '85797979', '45000', '60000', 'Ofii', '2025-01-10', '2025-01-24', 'a.jpg', 'Desert.jpg', 'asfasfasf', '2025-01-18');

-- --------------------------------------------------------

--
-- Table structure for table `helpline`
--

CREATE TABLE IF NOT EXISTS `helpline` (
  `help_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `cntno` text NOT NULL,
  `entno` text NOT NULL,
  `email` text NOT NULL,
  `servce` text NOT NULL,
  `Log_Id` varchar(200) NOT NULL,
  `photo` varchar(200) NOT NULL,
  PRIMARY KEY (`help_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `helpline`
--

INSERT INTO `helpline` (`help_id`, `name`, `cntno`, `entno`, `email`, `servce`, `Log_Id`, `photo`) VALUES
(2, 'Urgent', '9797646464', '6462352352', 'ab@gmail.com', 'jlsdhgshgld', 'DS12444656HDHD', 'chrysanthemum - Copy.jpg'),
(3, 'Urgent', '9797646464', '6462352352', 'ab@gmail.com', 'jlsdhgshgld', 'DS12444656HDHD', 'chrysanthemum - Copy.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `Log_Id` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `cntno` varchar(200) NOT NULL,
  `subj` varchar(200) NOT NULL,
  `about` text NOT NULL,
  `sdate` text NOT NULL,
  `stime` varchar(200) NOT NULL,
  `reply` text NOT NULL,
  `rdate` text NOT NULL,
  `rtime` varchar(200) NOT NULL,
  `sstatus` varchar(200) NOT NULL,
  `photo` varchar(200) NOT NULL,
  PRIMARY KEY (`msg_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`msg_id`, `Log_Id`, `name`, `cntno`, `subj`, `about`, `sdate`, `stime`, `reply`, `rdate`, `rtime`, `sstatus`, `photo`) VALUES
(1, 'DS12444656HDHD98765', 'Rasi', '9847169014', 'Hi', 'How R U', '17-01-2025', '08:32:55 PM', 'dsdgsd', '19-01-2025', '08:05:22 PM', 'clear', 'Desert.jpg'),
(2, 'DS12444656HDHD98765', 'Rasi', '9847169014', 'Hi', 'How R U', '17-01-2025', '08:33:09 PM', 'asfas', '19-01-2025', '08:55:17 PM', 'clear', 'Desert.jpg'),
(3, 'DS12444656HDHD987', 'Sham', '9847169014', 'rt', 'urtuerurt', '17-01-2025', '09:15:55 PM', '', '', '', 'Pending', 'Desert.jpg'),
(4, 'DS12444656HDHD98765', 'Rasi', '9847169014', 'dgds', 'sdgsd', '19-01-2025', '09:08:32 PM', '', '', '', 'Pending', 'b.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `messing_people`
--

CREATE TABLE IF NOT EXISTS `messing_people` (
  `msbg_id` int(11) NOT NULL AUTO_INCREMENT,
  `pname` text NOT NULL,
  `age` text NOT NULL,
  `sex` text NOT NULL,
  `addrs` text NOT NULL,
  `district` text NOT NULL,
  `panchayath` text NOT NULL,
  `village` text NOT NULL,
  `ward` text NOT NULL,
  `aadhar` text NOT NULL,
  `location` text NOT NULL,
  `oname` text NOT NULL,
  `date` date NOT NULL,
  `photo1` text NOT NULL,
  `photo2` text NOT NULL,
  `desp` text NOT NULL,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`msbg_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `messing_people`
--

INSERT INTO `messing_people` (`msbg_id`, `pname`, `age`, `sex`, `addrs`, `district`, `panchayath`, `village`, `ward`, `aadhar`, `location`, `oname`, `date`, `photo1`, `photo2`, `desp`, `status`) VALUES
(1, 'Raj', '20', 'Male', 'Palakkad', 'Palakkad', 'Kottayi', 'Kottayi', 'Kottayi', '679797979', 'Palakkad', 'Ko', '2025-12-31', 'a.jpg', 'b.jpg', 'ASFASFASF', 'Clear'),
(2, 'Ram', '20', 'Male', 'Palakkad', 'Palakkad', 'Kottayi', 'Kottayi', 'Kottayi', '679797979', 'Palakkad', 'Ko', '2025-12-31', 'a.jpg', 'b.jpg', 'safasfsafsa', 'Missing'),
(3, 'Rani', '20', 'Male', 'Palakkad', 'Palakkad', 'Kottayi', 'Kottayi', 'Kottayi', '679797979', 'Palakkad', 'Ko', '2025-12-31', 'a.jpg', 'b.jpg', 'safasfsafsa', 'Missing'),
(4, 'Rasu', '20', 'Male', 'Palakkad', 'Palakkad', 'Kottayi', 'Kottayi', 'Kottayi', '679797979', 'Palakkad', 'Ko', '2025-12-31', 'a.jpg', 'b.jpg', 'safasfsafsa', 'Missing'),
(5, 'Rak', '20', 'Male', 'Palakkad', 'Palakkad', 'Kottayi', 'Kottayi', 'Kottayi', '679797979', 'Palakkad', 'Ko', '2025-12-31', 'a.jpg', 'b.jpg', 'safasfsafsa', 'Missing');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE IF NOT EXISTS `notification` (
  `not_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `subj` text NOT NULL,
  `about` text NOT NULL,
  `date` text NOT NULL,
  `tm` varchar(200) NOT NULL,
  `Log_Id` varchar(200) NOT NULL,
  `photo` varchar(200) NOT NULL,
  PRIMARY KEY (`not_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`not_id`, `name`, `subj`, `about`, `date`, `tm`, `Log_Id`, `photo`) VALUES
(7, 'sdg', 'dgsdg', 'dgsdg', '16-01-2025', '09:06:18 PM', 'DST812324980', 'chrysanthemum.jpg'),
(2, 'His', 'Nice', 'Nice\r\n', '14-01-2025', '09:03:23 PM', 'DS12444656HDHD', 'chrysanthemum - Copy.jpg'),
(3, 'reyery', 'eryery', 'eryery', '14-01-2025', '09:06:00 PM', 'DS12444656HDHD', 'chrysanthemum - Copy.jpg'),
(4, 'reyery', 'eryery', 'eryery', '14-01-2025', '09:06:59 PM', 'DS12444656HDHD', 'chrysanthemum - Copy.jpg'),
(8, 'RTURT', 'URTUR', 'TURTURTU', '17-01-2025', '07:44:22 AM', 'DS12444656HDHD98765', 'b.jpg'),
(9, 'eery', 'eryer', 'yeryery', '17-01-2025', '09:14:45 PM', 'DS12444656HDHD987', 'Jellyfish.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `people`
--

CREATE TABLE IF NOT EXISTS `people` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `Log_Id` varchar(200) NOT NULL,
  `name` text,
  `sex` text,
  `age` int(3) DEFAULT NULL,
  `blgrp` varchar(15) DEFAULT NULL,
  `addrs` text,
  `district` text,
  `location` text,
  `pinocde` text,
  `email` text,
  `contactno` text,
  `username` text,
  `password` text NOT NULL,
  `photo` text NOT NULL,
  `stat` text NOT NULL,
  `utype` varchar(200) NOT NULL,
  `aadharno` varchar(200) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `people`
--

INSERT INTO `people` (`user_id`, `Log_Id`, `name`, `sex`, `age`, `blgrp`, `addrs`, `district`, `location`, `pinocde`, `email`, `contactno`, `username`, `password`, `photo`, `stat`, `utype`, `aadharno`, `date`) VALUES
(1, 'DS12444656HDHD987', 'Sham', 'Male', 20, 'A', 'Palakakd', 'Palakkad', 'Palakkad', '678572', 'sham@gmail.com', '9847169014', 'yasir@gmail.com', '123456', 'Jellyfish.jpg', 'Active', 'People', '', '2025-01-12');

-- --------------------------------------------------------

--
-- Table structure for table `rquest_register`
--

CREATE TABLE IF NOT EXISTS `rquest_register` (
  `req_id` int(11) NOT NULL AUTO_INCREMENT,
  `Log_Id` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `cntno` varchar(200) NOT NULL,
  `addr` text NOT NULL,
  `subj` varchar(200) NOT NULL,
  `fdate` date NOT NULL,
  `tdate` date NOT NULL,
  `ttime` varchar(200) NOT NULL,
  `photo` text NOT NULL,
  `servce` text NOT NULL,
  `RLog_Id` varchar(200) NOT NULL,
  `rname` varchar(200) NOT NULL,
  `raddr` text NOT NULL,
  `rcntno` varchar(200) NOT NULL,
  `rstatus` varchar(200) NOT NULL,
  PRIMARY KEY (`req_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `rquest_register`
--

INSERT INTO `rquest_register` (`req_id`, `Log_Id`, `name`, `cntno`, `addr`, `subj`, `fdate`, `tdate`, `ttime`, `photo`, `servce`, `RLog_Id`, `rname`, `raddr`, `rcntno`, `rstatus`) VALUES
(1, 'DS12444656HDHD9876A', 'Rasi', '9847169014', 'Palakkad', 'safasfas', '2025-01-17', '2025-01-31', '20:08', 'a.jpg', 'afasfasf', 'DS12444656HDHD98765', 'Rasi', 'Palakkad', '9847169014', 'Accept'),
(2, 'DS12444656HDHD98765A', 'Rasi', '9847169014', 'Palakkad', 'safasfas', '2025-01-17', '2025-01-31', '20:08', 'a.jpg', 'afasfasf', 'DS12444656HDHD987', 'Sham', 'Palakakd', '9847169014', 'Accept'),
(3, 'DS12444656HDHD98765', 'Rasi', '9847169014', 'Palakkad', 'safasfas', '2025-01-17', '2025-01-31', '20:08', 'a.jpg', 'afasfasf', '', '', '', '', 'Pending'),
(4, 'DS12444656HDHD98765', 'Rasi', '9847169014', 'Palakkad', 'safasfas', '2025-01-17', '2025-01-31', '20:08', 'a.jpg', 'afasfasf', 'DS12444656HDHD987', 'Sham', 'Palakakd', '9847169014', 'Accept'),
(5, 'DS12444656HDHD98765', 'Rasi', '9847169014', 'Palakkad', 'safasfas', '2025-01-17', '2025-01-31', '20:08', 'a.jpg', 'afasfasf', '', '', '', '', 'Pending'),
(6, 'DS12444656HDHD987', 'Sham', '9847169014', 'Palakakd', 'sgsdgs', '2025-01-24', '2025-01-22', '21:09', 'Tulips.jpg', 'sdgsdgsdg', '', '', '', '', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `volunteer`
--

CREATE TABLE IF NOT EXISTS `volunteer` (
  `voln_id` int(11) NOT NULL AUTO_INCREMENT,
  `Log_Id` varchar(200) NOT NULL,
  `name` text,
  `sex` text,
  `age` int(3) DEFAULT NULL,
  `blgrp` varchar(15) DEFAULT NULL,
  `addrs` text,
  `district` text,
  `location` text,
  `pinocde` text,
  `qulf` text,
  `job` text,
  `experincs` text,
  `servce` text,
  `email` text,
  `contactno` text,
  `username` varchar(200) NOT NULL,
  `password` text NOT NULL,
  `photo` text NOT NULL,
  `stat` text NOT NULL,
  `utype` varchar(200) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`voln_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `volunteer`
--

INSERT INTO `volunteer` (`voln_id`, `Log_Id`, `name`, `sex`, `age`, `blgrp`, `addrs`, `district`, `location`, `pinocde`, `qulf`, `job`, `experincs`, `servce`, `email`, `contactno`, `username`, `password`, `photo`, `stat`, `utype`, `date`) VALUES
(1, 'DS12444656HDHD98765', 'Rasi', 'Female', 20, '', 'Palakkad', 'Palakkad', 'Palakkad', '678572', '+2', 'Nice', 'One YEar', 'Nice Work', 'rasa@gmail.com', '9847169014', 'rasa@gmail.com', '123456', 'b.jpg', 'Active', 'Volunteer', '2025-01-12'),
(2, 'DS12444656HDHD23523', 'Ras', 'Male', 20, NULL, 'Palakkad', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'rassss@gmail.com', '9847169014', 'rrrr', '123456', 'a.jpg', 'Active', 'Volunteer', '2025-01-12');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

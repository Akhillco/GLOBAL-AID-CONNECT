`<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_USER_ID'];
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <div class="col-8 grid-margin">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Help Line</h4>
                      <div class="row">
                        <div class="col-md-12 h-100">
                          <div class="bg-secondary p-4">
                            <div id="profile-list-left" class="py-2">
                              <?php
							  	$result = $db->prepare("select * from  helpline");
								$result->execute();
								for($i=1; $row = $result->fetch(); $i++)
									{
									$help_id = $row['help_id'];
							  ?>
                              <div class="card rounded mb-2">
                                <div class="card-body p-3">
                                  <div class="media">
                                    <img src="../photo/<?php echo $row["photo"];?>" alt="image" class="img-sm me-3 rounded-circle">
                                    <div class="media-body">
                                    	<table class="table table-danger">
                                        	<tr>
                                            	<th>Name</th>
                                                <th>Contact</th>
                                                <th>Contact</th>
                                                <th>Email</th>
                                                <th>Service</th>
                                            </tr>
                                            <tr>
                                            	<td><?php echo $row["name"];?></td>
                                                <td><?php echo $row["cntno"];?></td>
                                                <td><?php echo $row["entno"];?></td>
                                                <td><?php echo $row["email"];?></td>
                                                <td><?php echo $row["servce"];?></td>
                                            </tr>
                                        </table>
                                    </div>                              
                                  </div>                                   
                                </div>
                              </div>
                              <?php
									}
							  ?>
                            </div>
                          </div>
                        </div>
                        
                      </div>
                    </div>
                  </div>
             </div>
            
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_USER_ID'];
	$pname= $_POST['pname'];
	$result = $db->prepare("select * from messing_people where pname='$pname'");
	$result->execute();
	for ($i = 0; $row = $result->fetch(); $i++) 
	{
			
		$pname=$row["pname"];
		$age=$row["age"];
		$sex=$row["sex"];
		$addrs=$row["addrs"];
		$district=$row["district"];
		$panchayath=$row["panchayath"];
		$village=$row["village"];
		$ward=$row["village"];
		$aadhar=$row["aadhar"];
		$location=$row["location"];
		$oname=$row["oname"];
		$date=$row["date"];
		$desp=$row["desp"];
		$status=$row["status"];
		$photo1=$row["photo1"];	
  	 	$photo2=$row["photo2"];	
	}
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row start -->
          <div class="col-md-12 col-xl-9 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Missing People</h4>
                  <p class="card-description">Information</p>                 
                   <ul class="nav nav-pills nav-pills-success" id="pills-tab" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link active" id="personala" data-bs-toggle="tab" href="#personal" role="tab" aria-controls="home-3" aria-selected="true">
                        Personal Details
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="addressa" data-bs-toggle="tab" href="#address" role="tab" aria-controls="home-3" aria-selected="false">
                     Address
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="missingaa" data-bs-toggle="tab" href="#missinga" role="tab" aria-controls="contact-3" aria-selected="false">
                        Missing
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" id="finda" data-bs-toggle="tab" href="#find" role="tab" aria-controls="contact-3" aria-selected="false">
                       Find
                      </a>
                    </li>
                  </ul>
                  <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="personal" role="tabpanel" aria-labelledby="personala">
                      <div class="media">
                        <img class="me-3 w-25 rounded" src="../photo/<?php echo $photo1;?>" alt="sample image">
                        <div class="media-body">
                          <h5 class="mt-0"><?php echo $pname;?></h5>
                         <table class="table table-primary" style="width:550px">
                            <thead>
                                <tr>
                                    <th>Aadhar No</th>
                                    <th>Name</th>
                                    <th>Age</th>
                                    <th>Gender</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo $aadhar;?></td>
                                    <td><?php echo $pname;?></td>
                                    <td><?php echo $age;?></td>
                                    <td><?php echo $sex;?></td>
                                </tr>
                            </tbody>
                        </table> 
                        </div>
                      </div>
                    </div>
                    <div class="tab-pane fade" id="address" role="tabpanel" aria-labelledby="addressa">
                      <div class="media">
                        <img class="me-3 w-25 rounded" src="../photo/<?php echo $photo2;?>" alt="sample image">
                        <div class="media-body">
                          <table class="table table-warning" style="width:550px">
                            <thead>
                                <tr>
                                    <th>Address</th>
                                    <th>District</th>
                                    <th>Panchayath</th>
                                    <th>Village</th>
                                    <th>Ward</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo $addrs;?></td>
                                    <td><?php echo $district;?></td>
                                    <td><?php echo $panchayath;?></td>
                                    <td><?php echo $village;?></td>
                                    <td><?php echo $ward;?></td>
                                </tr>
                            </tbody>
                        </table> 
                        </div>
                      </div>
                    </div>
                    <div class="tab-pane fade" id="missinga" role="tabpanel" aria-labelledby="missingaa">
                      <div class="media">
                        <img class="me-3 w-25 rounded" src="../photo/<?php echo $photo1;?>" alt="sample image">
                        <div class="media-body">
                         <table class="table table-danger" style="width:550px">
                            <thead>
                                <tr>
                                    <th>Location</th>
                                    <th>Officer</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo $location;?></td>
                                    <td><?php echo $oname;?></td>
                                    <td><?php echo $date;?></td>
                                </tr>
                            </tbody>
                        </table> 
                        </div>
                      </div>
                    </div>

                    <div class="tab-pane fade" id="find" role="tabpanel" aria-labelledby="finda">
                      <div class="media">
                        <img class="me-3 w-25 rounded" src="../photo/<?php echo $photo2;?>" alt="sample image">
                        <div class="media-body">
                          <table class="table table-info" style="width:550px">
                            <thead>
                                <tr>
                                    <th>Description</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo $desp;?></td>
                                    <td><?php echo $status;?></td>
                                </tr>
                            </tbody>
                        </table> 
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          <!-- row end -->
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


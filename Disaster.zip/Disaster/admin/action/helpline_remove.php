<?php
include("../../connect/db.php");

	$help_id=$_GET["help_id"];	
	
$sql = "delete from helpline where help_id='$help_id'";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../helpline_search.php");
?>

<?php
include("../../connect/db.php");

	$name=$_POST["name"];
	$cntno=$_POST["cntno"];
	$entno=$_POST["entno"];
	$email=$_POST["email"]; 
	$servce=$_POST["servce"];
	$Log_Id=$_POST["Log_Id"];
	$photo=$_POST["photo"];
	
$sql = "insert into helpline(name,cntno,entno,email,servce,Log_Id,photo)values('$name','$cntno','$entno','$email','$servce','$Log_Id','$photo')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../helpline_search.php");
?>

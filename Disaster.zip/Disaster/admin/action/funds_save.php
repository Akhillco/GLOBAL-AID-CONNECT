<?php
include("../../connect/db.php");

	
	$people=$_POST["people"];
	$sex=$_POST["sex"];
	$age=$_POST["age"];
	$addrs=$_POST["addrs"];
	$aadharno=$_POST["aadharno"];
	$district=$_POST["district"];
	$panchayath=$_POST["panchayath"];
	$village=$_POST["village"];
	$bank=$_POST["bank"];
	$accno=$_POST["accno"];
	$amnt=$_POST["amnt"];
	$issun=$_POST["issun"];
	$offname=$_POST["offname"];
	$fdate=$_POST["fdate"];
	$idate=$_POST["idate"];
	$date=date("Y-m-d");
	$desp=$_POST["desp"];
	
	$image = addslashes(file_get_contents($_FILES['iphoto']['tmp_name']));
	$image_name = addslashes($_FILES['iphoto']['name']);
	$image_size = getimagesize($_FILES['iphoto']['tmp_name']);
	move_uploaded_file($_FILES["iphoto"]["tmp_name"], "../../photo/" . $_FILES["iphoto"]["name"]);
	$iphoto = $_FILES["iphoto"]["name"];
	
	$image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
	$image_name = addslashes($_FILES['photo']['name']);
	$image_size = getimagesize($_FILES['photo']['tmp_name']);
	move_uploaded_file($_FILES["photo"]["tmp_name"], "../../photo/" . $_FILES["photo"]["name"]);
	$photo = $_FILES["photo"]["name"];
	
	
	
$sql = "insert into funds(people,sex,age,addrs,aadharno,district,panchayath,village,bank,accno,amnt,issun,offname,fdate,idate,iphoto,photo,desp,date)values('$people','$sex','$age','$addrs','$aadharno','$district','$panchayath','$village','$bank','$accno','$amnt','$issun','$offname','$fdate','$idate','$iphoto','$photo','$desp','$date')";
$q1 = $db->prepare($sql);
$q1->execute();

$sql = "update complaints set dstatus='issue' where name='$people'";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../funds_issued.php");
?>

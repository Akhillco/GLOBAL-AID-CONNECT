<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_ADMIN_ID'];
	$dep_id= $_GET['dep_id'];
	$result = $db->prepare("select * from department where dep_id='$dep_id'");
	$result->execute();
	for ($i = 0; $row = $result->fetch(); $i++) 
	{
			
		 $departmnt=$row["departmnt"];
		 $name=$row["name"];
		 $cntno1=$row["cntno1"];
		 $cntno2=$row["cntno2"];
		 $addr=$row["addr"];
		 $email=$row["email"];
		 $username=$row["username"];
		 $password=$row["password"];
		 $about=$row["about"];	
		 $photo=$row["photo"];	
	}
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <div class="col-md-6 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Department Update</h4>
                            <hr>
                            <form method="post" action="action/department_update.php" class="forms" autocomplete="off" enctype="multipart/form-data">
                                <div class="col-md-12">
                                    <label>Department Name</label>
                                    <input list="departmnt" required class="form-control" name="departmnt" value="<?php echo $departmnt;?>">
                                    <datalist id="departmnt">
                                         <?php
                                            $result = $db->prepare("select * from department");
                                            $result->execute();
                                            for($i=0; $rows = $result->fetch(); $i++)
                                            {
                                            echo '<option>'.$rows['departmnt'].'</option>';
                                            }
                                        ?>	                                         					
                                    </datalist>  
                                </div>
                                <div class="col-md-12">
                                    <label>Incharge Name</label>
                                    <input type="hidden" name="dep_id" value="<?php echo $dep_id;?>">
                                    <input type="text" name="name" class="form-control" value="<?php echo $name;?>" required pattern="[a-zA-Z1 _]{3,50}">
                                </div>
                                <div class="col-md-12">
                                    <label>Office Contact No</label>
                                    <input type="text" name="cntno1" class="form-control" value="<?php echo $cntno1;?>" pattern="[0-9]{10,10}" maxlength="10" minlength="10" required>
                                </div>
                                <div class="col-md-12">
                                    <label>Incharge Contact No</label>
                                    <input type="text" name="cntno2" class="form-control" value="<?php echo $cntno2;?>" pattern="[0-9]{10,10}" maxlength="10" minlength="10" required>
                                </div>
                                <div class="col-md-12">
                                    <label>Address</label>
                                    <textarea name="addr" class="form-control" required rows="4"><?php echo $addr;?></textarea>
                                </div>    
                                <div class="col-md-12">
                                    <label>Email</label>
                                    <input type="email" name="email" class="form-control" value="<?php echo $email;?>" required>
                                </div>  
                                <div class="col-md-12">
                                    <label>Username</label>
                                    <input type="username" class="form-control" name="username" value="<?php echo $username;?>" required minlength="4">
                                </div>                        
                                <div class="col-md-12">
                                    <label>Password</label>
                                    <input type="password" class="form-control" name="password" value="<?php echo $password;?>" required minlength="4">
                                </div>
                                 <div class="col-md-12">
                                    <label>Photo</label>
                                    <input type="file" name="photo" class="form-control" accept=".png, .jpg, .jpeg">
                                </div>  
                                 <div class="col-md-12">
                                    <label>About</label>
                                    <textarea name="about" class="form-control" required rows="4"><?php echo $about;?></textarea>
                                </div> 
                                <div class="col-xs-12 text-right">
                                    <br>
                                    <input type="submit" value="Submit" class="btn float-right btn-primary" style="float:right">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- New End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


<?php
include("../../connect/db.php");

	$pname=$_POST["pname"];
	$age=$_POST["age"];
	$sex=$_POST["sex"];
	$addrs=$_POST["addrs"];
	$district=$_POST["district"];
	$panchayath=$_POST["panchayath"];
	$village=$_POST["village"];
	$ward=$_POST["village"];
	$aadhar=$_POST["aadhar"];
	$location=$_POST["location"];
	$oname=$_POST["oname"];
	$date=$_POST["date"];
	$desp=$_POST["desp"];
	$status="Missing";
	 
	$image = addslashes(file_get_contents($_FILES['photo1']['tmp_name']));
	$image_name = addslashes($_FILES['photo1']['name']);
	$image_size = getimagesize($_FILES['photo1']['tmp_name']);
	move_uploaded_file($_FILES["photo1"]["tmp_name"], "../../photo/" . $_FILES["photo1"]["name"]);
	$photo1 = $_FILES["photo1"]["name"];
	
	$image = addslashes(file_get_contents($_FILES['photo2']['tmp_name']));
	$image_name = addslashes($_FILES['photo2']['name']);
	$image_size = getimagesize($_FILES['photo2']['tmp_name']);
	move_uploaded_file($_FILES["photo2"]["tmp_name"], "../../photo/" . $_FILES["photo2"]["name"]);
	$photo2 = $_FILES["photo2"]["name"];
		
$sql = "insert into messing_people(pname,age,sex,addrs,district,panchayath,village,ward,aadhar,location,oname,date,photo1,photo2,desp,status)values('$pname','$age','$sex','$addrs','$district','$panchayath','$village','$ward','$aadhar','$location','$oname','$date','$photo1','$photo2','$desp','$status')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../missing_people_search.php");
?>

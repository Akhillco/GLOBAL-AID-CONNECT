<?php
include("../../connect/db.php");

	 $Log_Id=$_POST["Log_Id"];
	 $departmnt=$_POST["departmnt"];
	 $name=$_POST["name"];
	 $cntno1=$_POST["cntno1"];
	 $cntno2=$_POST["cntno2"];
	 $addr=$_POST["addr"];
	 $email=$_POST["email"];
	 $username=$_POST["username"];
	 $password=$_POST["password"];
	 $about=$_POST["about"];
	 

	$image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
	$image_name = addslashes($_FILES['photo']['name']);
	$image_size = getimagesize($_FILES['photo']['tmp_name']);
	move_uploaded_file($_FILES["photo"]["tmp_name"], "../../photo/" . $_FILES["photo"]["name"]);
	$photo = $_FILES["photo"]["name"];
	
	if($photo=="")
	{
		$sql = "update department set departmnt='$departmnt',name='$name',cntno1='$cntno1',cntno2='$cntno2',addr='$addr',email='$email',username='$username',password='$password',about='$about' where Log_Id='$Log_Id'";
	$q1 = $db->prepare($sql);
	$q1->execute();
	}
	else
	{
		$sql = "update department set departmnt='$departmnt',name='$name',cntno1='$cntno1',cntno2='$cntno2',addr='$addr',email='$email',username='$username',password='$password',about='$about',photo='$photo' where Log_Id='$Log_Id'";
		$q1 = $db->prepare($sql);
		$q1->execute();
	}
	header("location:../profile_settings.php");
?>

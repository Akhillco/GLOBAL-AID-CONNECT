<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_DEPT_ID'];
	$result = $db->prepare("select * from department where Log_Id='$Log_Id'");
	$result->execute();
	for ($i = 0; $row = $result->fetch(); $i++) 
	{
			
		$photo= $row['photo'];
	}
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <div class="col-md-6 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">New Notification Send</h4>
                            <hr>
                            <form method="post" action="action/notification_save.php" class="forms" autocomplete="off">                           
                                <div class="col-md-12">
                                    <label>Name</label>
                                    	<input type="hidden"  name="Log_Id" value="<?php echo $Log_Id?>">     
                                        <input type="hidden"  name="photo" value="<?php echo $photo?>">    
                                        <input type="text"  name="name" class="form-control" required pattern="[a-zA-Z]*">                  
                                </div> 
                                <div class="col-md-12">
                                    <label>Subject</label>
                                        <input type="text"  name="subj" class="form-control" required>                  
                                </div> 
                                <div class="col-md-12">
                                    <label>About</label>
                                    <textarea  name="about" class="form-control" rows="5" required></textarea>
                                </div>                                                   
                                <div class="col-xs-12 text-right">
                                        <br>
                                        <input type="submit" value="Send" style="float: right;" class="btn float-right btn-info">
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- New End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


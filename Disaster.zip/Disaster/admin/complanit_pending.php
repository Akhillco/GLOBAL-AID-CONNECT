<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_ADMIN_ID'];
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                	<?php 
				$result = $db->prepare("select * from complaints where aststus='Pending'");
				$result->execute();
				for ($i = 0; $row = $result->fetch(); $i++) 
				{
				?>
                <div class="col-12 grid-margin stretch-card d-none d-md-flex">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Complaints Pending</h4>
                      <hr>
                      <div class="row">
                        
                        <div class="col-3">
                          <ul class="nav nav-tabs nav-tabs-vertical-custom" role="tablist" style="background-color:brown;">
                            <li class="nav-item">
                              <a class="nav-link active" id="profilea<?php echo $row["cmp_id"];?>" data-bs-toggle="tab" href="#profile<?php echo $row["cmp_id"];?>" role="tab" aria-controls="home-3" aria-selected="true">
                                Profile 
                              </a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" id="complaintu<?php echo $row["cmp_id"];?>" data-bs-toggle="tab" href="#complaintas<?php echo $row["cmp_id"];?>" role="tab" aria-controls="home-3" aria-selected="false">
                              Address
                              </a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" id="photoa<?php echo $row["cmp_id"];?>" data-bs-toggle="tab" href="#photo<?php echo $row["cmp_id"];?>" role="tab" aria-controls="contact-3" aria-selected="false">
                                Photos
                              </a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" id="videoa<?php echo $row["cmp_id"];?>" data-bs-toggle="tab" href="#video<?php echo $row["cmp_id"];?>" role="tab" aria-controls="contact-3" aria-selected="false">
                                Video
                              </a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" id="statusa<?php echo $row["cmp_id"];?>" data-bs-toggle="tab" href="#status<?php echo $row["cmp_id"];?>" role="tab" aria-controls="contact-3" aria-selected="false">
                               Complaint
                              </a>
                            </li>
                          </ul>
                        </div>
                        <div class="col-9 col-lg-9">
                          <div class="tab-content tab-content-vertical tab-content-vertical-custom">
                            <div class="tab-pane fade show active" id="profile<?php echo $row["cmp_id"];?>" role="tabpanel" aria-labelledby="profilea<?php echo $row["cmp_id"];?>">
                            <h5 class="mt-0 mb-1">Personal Details</h5>
                                  <hr>
                            	<table class="table table-primary">
                                	<thead>
                                        <tr>
                                            <th>Aadhar No</th>
                                            <th>Name</th>
                                            <th>Gender</th>
                                            <th>Age</th>
                                            <th>Email</th>
                                            <th>Contact</th>
                                            <th>Contact</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    	<tr>
                                        	<td><?php echo $row["aadharno"];?></td>
                                            <td><?php echo $row["name"];?></td>
                                            <td><?php echo $row["age"];?></td>
                                            <td><?php echo $row["sex"];?></td>
                                            <td><?php echo $row["email"];?></td>
                                            <td><?php echo $row["contactno1"];?></td>
                                            <td><?php echo $row["contactno2"];?></td>
                                        </tr>
                                    </tbody>
                                </table>                    
                            </div>
                            <div class="tab-pane fade" id="complaintas<?php echo $row["cmp_id"];?>" role="tabpanel" aria-labelledby="complaintu<?php echo $row["cmp_id"];?>">
                              <div class="media">
                                <div class="media-body">
                                <h5 class="mt-0 mb-1">Address Details</h5>
                                  <hr>
                                  <table class="table table-info" style="width:700px;">
                                	<thead>
                                        <tr>
                                            <th>Address</th>
                                            <th>District</th>
                                            <th>Panchayath</th>
                                            <th>Thaluk</th>
                                            <th>Village</th>
                                            <th>Ward</th>
                                            <th>Station</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    	<tr>
                                        	<td><?php echo $row["addrs"];?></td>
                                            <td><?php echo $row["distict"];?></td>
                                            <td><?php echo $row["panchayath"];?></td>
                                            <td><?php echo $row["thaluk"];?></td>
                                            <td><?php echo $row["village"];?></td>
                                            <td><?php echo $row["wrd"];?></td>
                                            <td><?php echo $row["pstation"];?></td>
                                        </tr>
                                    </tbody>
                                </table> 
                                </div>
                              </div>
                            </div>
                            <div class="tab-pane fade" id="photo<?php echo $row["cmp_id"];?>" role="tabpanel" aria-labelledby="photoa<?php echo $row["cmp_id"];?>">
                              <div class="media">                              	
                                <img  style="width:350px; margin:5px;"src="../photo/<?php echo $row["photo"];?>" alt="sample image">
                                <img style="width:350px; margin:5px;" src="../photo/<?php echo $row["lphoto"];?>" alt="sample image">
                              </div>
                            </div>
                            <div class="tab-pane fade" id="video<?php echo $row["cmp_id"];?>" role="tabpanel" aria-labelledby="videoa<?php echo $row["cmp_id"];?>">
                              <div class="media">
                                <div class="media-body">
                                <h5 class="mt-0 mb-1">Location Details</h5>
                                <hr>
									<video controls width="100%" height="350">
                                    	<source src="../photo/<?php echo $row["video"];?>" type="video/mp4">
                                    </video>                                 
                                </div>                                
                              </div>
                            </div>
                            <div class="tab-pane fade" id="status<?php echo $row["cmp_id"];?>" role="tabpanel" aria-labelledby="statusa<?php echo $row["cmp_id"];?>">
                              <div class="media">
                                <div class="media-body">
                                  <h5 class="mt-0 mb-1">Complaint Details</h5>
                                  <hr>
                                 <table class="table table-info" style="width:700px;">
                                	<thead>
                                        <tr>
                                            <th>Complaint</th>
                                            <th>Date</th>
                                            <th>Department</th>
                                            <th>Govt</th>
                                            <th>Message</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    	<tr>
                                        	<td><?php echo $row["compl"];?></td>
                                            <td><?php echo $row["ddate"];?></td>
                                            <td><?php echo $row["dstatus"];?></td>
                                            <td><?php echo $row["aststus"];?></td>
                                            <td><?php echo $row["descp"];?></td>
                                        </tr>
                                    </tbody>
                                </table> 
                                <div class="row">
                                     <!-- New Request -->
                                    <div class="col-md-12 grid-margin stretch-card">
                                        <div class="card">
                                            <div class="card-body">
                                                <h4 class="card-title">Update Status</h4>
                                                <hr>
                                                <form method="post" action="action/complaint_update.php" class="forms" autocomplete="off">
                                                    <div class="row">
                                                         <div class="col-md-6">
                                                            <label>Name</label>
                                                            <input type="hidden"  name="cmp_id" value="<?php echo $row["cmp_id"];?>">
                                                            <input type="text"  name="name" class="form-control" value="<?php echo $row["name"];?>">
                                                        </div>     
                                                         <div class="col-md-6">
                                                            <label>Status</label>
                                                                <select name="status" class="form-control" style="height:50px; font-size:20px;">
                                                                    <option>Forward</option>
                                                                    <option>Clear</option>
                                                                    <option>Cancel</option>
                                                                </select>                                          
                                                        </div>       
                                                    </div>
                                                    <div class="row">                            
                                                        <div class="col-md-12">
                                                            <label>Message</label>
                                                            <textarea name="descp" class="form-control" required rows="4"></textarea>
                                                        </div>     
                                                    </div>                                       
                                                    <div class="col-xs-12 text-right">
                                                        <br>
                                                        <input type="submit" value="Submit" class="btn float-right btn-primary" style="float:right">
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- New End -->
                                
                                </div>
                                </div>                                
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- New End -->
            <?php }?>
    			<!-- End-->    
                
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


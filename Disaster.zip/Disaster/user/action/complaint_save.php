<?php
include("../../connect/db.php");

	$Log_Id=$_POST["Log_Id"];
	$departmnt=$_POST["departmnt"];
	$name=$_POST["name"];
	$aadharno=$_POST["aadharno"];
	$age=$_POST["age"];
	$sex=$_POST["sex"];
	$email=$_POST["email"];
	$wrd=$_POST["wrd"];
	$panchayath=$_POST["panchayath"];
	$village=$_POST["village"];
	$thaluk=$_POST["thaluk"];
	$distict=$_POST["distict"];
	$pstation=$_POST["pstation"];
	$contactno1=$_POST["contactno1"];
	$contactno2=$_POST["contactno2"];
	$addrs=$_POST["addrs"];
	$compl=$_POST["compl"];
	$ddate=$_POST["ddate"];
	$dstatus="Pending";
	$aststus="Pending";
	
	
	$image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
	$image_name = addslashes($_FILES['photo']['name']);
	$image_size = getimagesize($_FILES['photo']['tmp_name']);
	move_uploaded_file($_FILES["photo"]["tmp_name"], "../../photo/" . $_FILES["photo"]["name"]);
	$photo = $_FILES["photo"]["name"];
	
	$image = addslashes(file_get_contents($_FILES['video']['tmp_name']));
	$image_name = addslashes($_FILES['video']['name']);
	$image_size = getimagesize($_FILES['video']['tmp_name']);
	move_uploaded_file($_FILES["video"]["tmp_name"], "../../photo/" . $_FILES["video"]["name"]);
	$video = $_FILES["video"]["name"];
	
	$image = addslashes(file_get_contents($_FILES['lphoto']['tmp_name']));
	$image_name = addslashes($_FILES['lphoto']['name']);
	$image_size = getimagesize($_FILES['lphoto']['tmp_name']);
	move_uploaded_file($_FILES["lphoto"]["tmp_name"], "../../photo/" . $_FILES["lphoto"]["name"]);
	$lphoto = $_FILES["lphoto"]["name"];	
	
$sql = "insert into complaints(Log_Id,departmnt,name,aadharno,age,sex,email,wrd,panchayath,village,thaluk,distict,pstation,contactno1,contactno2,addrs,photo,video,compl,ddate,lphoto,dstatus,aststus)values('$Log_Id','$departmnt','$name','$aadharno','$age','$sex','$email','$wrd','$panchayath','$village','$thaluk','$distict','$pstation','$contactno1','$contactno2','$addrs','$photo','$video','$compl','$ddate','$lphoto','$dstatus','$aststus')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../complanit_pending.php");
?>

`<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_USER_ID'];
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
          <?php
		  	$result = $db->prepare("select * from  camp");
			$result->execute();
			for($i=1; $row = $result->fetch(); $i++)
				{
					$camp_id = $row['camp_id'];	
		  ?>
            <!-- row start -->
              <div class="col-md-12 col-xl-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">                  
                      <ul class="nav nav-pills nav-pills-success" id="pills-tab" role="tablist">
                        <li class="nav-item">
                          <a class="nav-link active" id="personal" data-bs-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Camp Details</a>
                        </li>                                        
                      </ul>
                      <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="personal" role="tabpanel" aria-labelledby="pills-home-tab">
                          <div class="media">
                            <img class="me-3 w-25 rounded" src="../photo/<?php echo $row["photo"];?>" alt="sample image">
                            <div class="media-body">
                              <table class="table table-bordered table-hover">       
                                <thead>
                                    <tr>              
                                        <th>Department</th>                  	
                                        <th>Name</th>
                                        <th>Contact</th>
                                        <th>From</th>                                    
                                        <th>To</th>
                                        <th>Time</th>
                                        <th>Address</th>
                                        <th>Description</th>
                                    </tr>
                                </thead>                   
                               <tbody>  
                                  <?php
										echo"<tr>";						
										echo"<td>".$row["departmnt"]."</td>";
										echo"<td>".$row["iname"]."</td>";	
										echo"<td>".$row["cntno"]."</td>";	
										echo"<td>".$row["fdate"]."</td>";
										echo"<td>".$row["tdate"]."</td>";
										echo"<td>".$row["time"]."</td>";
										echo"<td>".$row["addrs"]."</td>";	
										echo"<td>".$row["cdescp"]."</td>";	
										echo"</tr>";
                                    ?>	
                                </tbody>
                            </table>
                            	
                            </div>
                          </div>
                        </div>                    
                      </div>
                    </div>
                  </div>
                </div>
              <!-- row end -->
              <?php }?>
                <!-- New End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


`<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_VOL_ID'];
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <div class="col-md-8 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Report Disaster Place</h4>
                            <hr>
                            <form method="post" action="report_disaster_view.php" class="forms" autocomplete="off">   
                                <div class="row">
                                  <div class="col-md-6">
                                      <label>From</label>
                                          <input type="date" class="form-control" name="fdate" required max="<?php echo date("Y-m-d");?>">              
                                  </div>    
                                  <div class="col-md-6">
                                      <label>To</label>
                                          <input type="date" class="form-control" name="tdate" required max="<?php echo date("Y-m-d");?>">        
                                  </div>    
                                </div>
                                                                                                         
                                <div class="col-md-12 col-sm-6 col-xs-6">
                                    <br>
                                    <div class="col-md-12 col-sm-6 col-xs-12">
                                        <input type="submit" value="Search" class="btn btn-block btn-primary" style="float:right">
                                    </div>                          
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- New End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


`<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_ADMIN_ID'];
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
      <?php 
        include("include/header.php");
    ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            
            <div class="col-12 col-xl-6 grid-margin stretch-card">
              <div class="row w-100 flex-grow">
               
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-12 col-md-6 col-xl-3 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center justify-content-center">
                    <canvas height="260" class="mt-2" id="customers-chart"></canvas>
                    <h5 class="mb-2 mt-4">New Request</h5>
                    <h6 class="font-weight-normal">February 2025</h6>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-6 col-xl-3 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center justify-content-center">
                    <canvas height="260" class="mt-2" id="comments-chart"></canvas>
                    <h5 class="mb-2 mt-4">Volunteers</h5>
                    <h6 class="font-weight-normal">New Sessions</h6>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-6 col-xl-3 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center justify-content-center">
                    <canvas height="260" class="mt-2" id="total-sales-chart"></canvas>
                    <h5 class="mb-2 mt-4">Missing People</h5>
                    <h6 class="font-weight-normal">Last Yesr</h6>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-6 col-xl-3 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center justify-content-center">
                    <canvas height="260" class="mt-2" id="orders-chart"></canvas>
                    <h5 class="mb-2 mt-4">Fund Issue</h5>
                    <h6 class="font-weight-normal">Last Year 2024</h6>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <!-- row end -->
         
          <!-- row end -->
        <div class="row">
            <!-- New Request -->
            <div class="col-md-4 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">New Request</h4>
                         <?php 
						$result = $db->prepare("select * from rquest_register where  rstatus='Pending' limit 3");
						$result->execute();
						for ($i = 0; $row = $result->fetch(); $i++) 
						{
					 ?>   
                        <div class="d-flex align-items-center py-3 border-bottom">
                            <img class="img-sm rounded-circle" src="../photo/<?php echo $row["photo"];?>" alt="profile">
                            <div class="ms-3">
                                <h6 class="mb-1"><?php echo $row["name"];?></h6>
                                <small class="text-muted mb-0"><i class="mdi mdi-map-marker me-1"></i><?php echo $row["addr"];?></small>
                            </div>
                            <i class="mdi mdi-plus-circle-outline font-weight-bold ms-auto px-1 py-1 text-danger mdi-24px"></i>
                        </div>
                       <?php }?> 
                    </div>
                </div>
            </div>
            <!-- New End -->

            <!-- New Complaint -->
            <div class="col-md-8 grid-margin grid-margin-md-0 stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Complaints</h4>
                        <div class="table-responsive">
                            <table class="table">
                            <thead>
                                <tr>
                                    <th class="pt-1 pl-0">
                                        Name
                                    </th>
                                    <th class="pt-1">
                                        Complaint
                                    </th>
                                    <th class="pt-1">
                                        Date
                                    </th>
                                    <th class="pt-1">
                                        Status
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                             <?php 
								$result = $db->prepare("select * from complaints where  aststus='Pending' limit 3");
								$result->execute();
								for ($i = 0; $row = $result->fetch(); $i++) 
								{
							 ?>   
                                <tr>
                                    <td class="py-1 pl-0">
                                        <div class="d-flex align-items-center">
                                        <img src="../photo/<?php echo $row["photo"];?>" alt="profile"/>
                                        <div class="ms-3">
                                            <p class="mb-0"><?php echo $row["name"];?></p>
                                            <p class="mb-0 text-muted text-small"><?php echo $row["addrs"];?></p>
                                        </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php echo $row["compl"];?>
                                    </td>
                                     <td>
                                       <?php echo $row["ddate"];?>
                                    </td>
                                    <td>
                                        <label class="badge badge-danger"><?php echo $row["aststus"];?></label>
                                    </td>
                                </tr>
							<?php }?>	
                            </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- New End -->
        </div>
        <!-- New Missing -->
        <div class="row">
            <label class="alert alert-primary text-black">Missing People</label>
             <?php 
				$result = $db->prepare("select * from messing_people limit 3");
				$result->execute();
				for ($i = 0; $row = $result->fetch(); $i++) 
				{
			 ?>   
            <div class="col-md-4 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <div class="d-sm-flex flex-row flex-wrap text-center text-sm-left align-items-center">
                            <img src="../photo/<?php echo $row["photo1"];?>" class="img-lg rounded" alt="profile image"/>
                            <div class="ml-sm-3 ml-md-0 ml-xl-3 mt-2 mt-sm-0 mt-md-2 mt-xl-0">
                                <h6 class="mb-0"> <?php echo $row["pname"];?></h6>
                                <p class="text-muted mb-1"> <?php echo $row["addrs"];?></p>
                                <p class="mb-0 text-success font-weight-bold"> <?php echo $row["date"];?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
		<?php }?>
        </div>
        <!-- New End -->

        <!-- New Fund Issue -->
        <div class="row">
        <label class="alert alert-danger text-black">Fund Issue</label>
        <?php 
				$result = $db->prepare("select * from funds limit 3");
				$result->execute();
				for ($i = 0; $row = $result->fetch(); $i++) 
				{
			 ?>   
            <div class="col-md-4 grid-margin grid-margin-md-0 stretch-card">
                <div class="card">
                    <div class="card-body text-center">
                        <div>
                            <img src="../photo/<?php echo $row["photo"];?>" class="img-lg rounded-circle mb-2" alt="profile image"/>
                            <h4><?php echo $row["people"];?></h4>
                            <p class="text-muted mb-0"><?php echo $row["addrs"];?></p>
                        </div>
                        <p class="mt-2 card-text">
                              <?php echo $row["desp"];?>
                        </p>
                        <div class="border-top pt-3">
                            <div class="row">
                                <div class="col-4">
                                    <h6><?php echo $row["bank"];?></h6>
                                    <p>Bank</p>
                                </div>
                                <div class="col-4">
                                   <h6><?php echo $row["amnt"];?></h6>
                                    <p>Amount</p>
                                </div>
                                <div class="col-4">
                                   <h6><?php echo $row["issun"];?></h6>
                                    <p>Issue</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php }?>
        </div>
        <!-- New End -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


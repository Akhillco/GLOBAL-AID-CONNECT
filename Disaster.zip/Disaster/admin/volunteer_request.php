<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_ADMIN_ID'];
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
             <?php 
				$result = $db->prepare("select * from volunteer where stat='Pending'");
				$result->execute();
				for ($i = 0; $row = $result->fetch(); $i++) 
				{
					$voln_id=$row["voln_id"];
			 ?>   
              <div class="col-12">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-lg-4">
                      <div class="border-bottom text-center pb-4">
                        <img src="../photo/<?php echo $row["photo"];?>" alt="profile" class="img-lg rounded-circle mb-3"/>
                        <div class="mb-3">
                          <h3><?php echo $row["name"];?></h3>
                        </div>
                        <p class="w-75 mx-auto mb-3"><?php echo $row["addrs"];?> </p>
                        
                      </div>
                    </div>
                    <div class="col-lg-8">
                      <div class="d-block d-md-flex justify-content-between mt-4 mt-md-0">
                        <div class="text-center mt-4 mt-md-0">
                          <a href="#" class="btn btn-danger">Request</a>
                          <a href="action/volunteer_permission_active.php<?php echo '?voln_id='.$voln_id;?>" class="btn btn-outline-primary">Accept</a>
                          <a href="action/volunteer_permission_inactive.php<?php echo '?voln_id='.$voln_id;?>" class="btn btn-outline-info">Cancel</a>
                        </div>
                      </div>
                
                      <div class="profile-feed">
                        
                        <div class="d-flex align-items-start profile-feed-item">
                          <div class="col-lg-12">
                            <h6>
                              <table class="table">
                              	<tr>
                                	<th>Gender</th>
                                    <th>Age</th>
                                    <th>Phone No</th>
                                    <th>Email</th>
                                    <th>Date</th>
                                </tr>
                                <tr>
                                	<td><?php echo $row["sex"];?></td>
                                    <td><?php echo $row["age"];?></td>
                                    <td><?php echo $row["contactno"];?></td>
                                    <td><?php echo $row["email"];?></td>
                                    <td><?php echo $row["date"];?></td>
                                </tr>
                              </table>
                          </div>
                        </div>
                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <?php }?>
                <!-- New End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


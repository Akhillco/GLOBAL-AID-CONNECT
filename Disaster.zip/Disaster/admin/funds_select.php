<?php
include('../connect/db.php');
							
	$peoples=$_POST["peoples"];	
	$result = $db->prepare("SELECT * FROM complaints where name='$peoples'");
	$result->execute();
		for($i=0; $rows = $result->fetch(); $i++)
		{
			
			$data["name"] = $rows["name"];	
			$data["sex"] = $rows["sex"];	
			$data["age"] = $rows["age"];	
			$data["addrs"] = $rows["addrs"];	
			$data["aadharno"] = $rows["aadharno"];	
		}
		echo json_encode($data);
?>


                  		
                  								
                  							
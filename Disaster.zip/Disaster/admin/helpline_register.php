<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_ADMIN_ID'];
	$result = $db->prepare("select * from admin where Log_Id='$Log_Id'");
	$result->execute();
	for ($i = 0; $row = $result->fetch(); $i++) 
	{
			
		$photo= $row['photo'];
	}
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <div class="col-md-6 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">New Helpline Register</h4>
                            <hr>
                            <form method="post" action="action/helpline_save.php" class="forms" autocomplete="off">                           
                                <div class="col-md-12">
                                    <label>Name</label>
                                        <input type="text"  name="name" class="form-control" required>  
                                        <input type="hidden"  name="Log_Id" value="<?php echo $Log_Id?>">     
                                        <input type="hidden"  name="photo" value="<?php echo $photo?>">                  
                                </div> 
                                <div class="col-md-12">
                                    <label>Contact No</label>
                                    <input type="text"  name="cntno" class="form-control" pattern="[0-9]{10,10}" maxlength="10" minlength="10" required>
                                </div> 
                                <div class="col-md-12">
                                    <label>Emergency Contact No</label>
                                    <input type="text"  name="entno" class="form-control" pattern="[0-9]{10,10}" maxlength="10" minlength="10" required>
                                </div> 
                                <div class="col-md-12">
                                    <label>Email</label>
                                        <input type="email"  name="email" class="form-control" required>                 
                                </div>  
                                <div class="col-md-12">
                                    <label>Service</label>
                                        <input type="text"  name="servce" class="form-control" required>                 
                                </div>                                                                                  
                                <div class="col-xs-12 text-right">
                                        <br>
                                        <input type="submit" value="Submit" class="btn float-right btn-primary">
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- New End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_USER_ID'];
	$result = $db->prepare("select * from people where Log_Id='$Log_Id'");
	$result->execute();
	for ($i = 0; $row = $result->fetch(); $i++) 
	{
		 $name=$row["name"];
		 $sex=$row["sex"];
		 $age=$row["age"];
		 $blgrp=$row["blgrp"];
		 $addrs=$row["addrs"];
		 $district=$row["district"];
		 $location=$row["location"];
		 $pinocde=$row["pinocde"];
		 $email=$row["email"];
		 $contactno=$row["contactno"];
	}
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <div class="col-md-10 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">New Complaint Register</h4>
                            <hr>
                            <form method="post" action="action/complaint_save.php" class="forms" autocomplete="off" enctype="multipart/form-data">   
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>Department</label>
                                         <input list="departmnt" required class="form-control" name="departmnt" placeholder="Search">
                                            <datalist id="departmnt">
                                                <option value="">Select</option> 
                                                 <?php
                                                    $result = $db->prepare("select * from department");
                                                    $result->execute();
                                                    for($i=0; $rows = $result->fetch(); $i++)
                                                    {
                                                    echo '<option>'.$rows['departmnt'].'</option>';
                                                    }
                                                ?>	                                         					
                                            </datalist>                   
                                    </div>  
                                    <div class="col-md-6">
                                        <label>Name</label>
                                       		<input type="hidden"  name="Log_Id" value="<?php echo $Log_Id;?>">   
                                            <input type="text"  name="name" class="form-control"  value="<?php echo $name;?>" required pattern="[a-zA-Z]*">               
                                    </div> 
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>Aadhar No</label>
                                            <input type="text"  name="aadharno" class="form-control">               
                                    </div> 
                                    <div class="col-md-6">
                                        <label>Age</label>
                                            <input type="text"  name="age" class="form-control" value="<?php echo $age;?>" min="18" max="100" required>               
                                    </div> 
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>Gender</label>
                                            <input type="text"  name="sex" class="form-control" value="<?php echo $sex;?>" required>              
                                    </div> 
                                    <div class="col-md-6">
                                        <label>Email</label>
                                            <input type="email"  name="email" class="form-control" value="<?php echo $email;?>" required>                
                                    </div> 
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>Ward No</label>
                                            <input type="text"  name="wrd" class="form-control" required>                
                                    </div> 
                                    <div class="col-md-6">
                                        <label>Panchayath</label>
                                        	<input list="panchayath" required class="form-control" name="panchayath" placeholder="Search">
                                            <datalist id="panchayath">
                                                <option value="">Select</option> 
                                                 <?php
                                                    $result = $db->prepare("select distinct panchayath from complaints");
                                                    $result->execute();
                                                    for($i=0; $rows = $result->fetch(); $i++)
                                                    {
                                                    echo '<option>'.$rows['panchayath'].'</option>';
                                                    }
                                                ?>	                                         					
                                            </datalist>           
                                    </div> 
                                </div>
                                <div class="row">
                                	<div class="col-md-6">
                                        <label>Village</label>
                                        	<input list="village" required class="form-control" name="village" placeholder="Search">
                                            <datalist id="village">
                                                <option value="">Select</option> 
                                                 <?php
                                                    $result = $db->prepare("select distinct village from complaints");
                                                    $result->execute();
                                                    for($i=0; $rows = $result->fetch(); $i++)
                                                    {
                                                    echo '<option>'.$rows['village'].'</option>';
                                                    }
                                                ?>	                                         					
                                            </datalist>          
                                    </div> 
                                    <div class="col-md-6">
                                        <label>Thaluk</label>
                                        	<input list="thaluk" required class="form-control" name="thaluk" placeholder="Search">
                                            <datalist id="thaluk">
                                                <option value="">Select</option> 
                                                 <?php
                                                    $result = $db->prepare("select distinct thaluk from complaints");
                                                    $result->execute();
                                                    for($i=0; $rows = $result->fetch(); $i++)
                                                    {
                                                    echo '<option>'.$rows['thaluk'].'</option>';
                                                    }
                                                ?>	                                         					
                                            </datalist>              
                                    </div> 
                                    
                                </div>
                                <div class="row">
                                    
                                    <div class="col-md-6">
                                        <label>District</label>
                                        	<input list="distict" required class="form-control" name="distict" placeholder="Search">
                                            <datalist id="distict">
                                                <option value="">Select</option> 
                                                 <?php
                                                    $result = $db->prepare("select distinct distict from complaints");
                                                    $result->execute();
                                                    for($i=0; $rows = $result->fetch(); $i++)
                                                    {
                                                    echo '<option>'.$rows['distict'].'</option>';
                                                    }
                                                ?>	                                         					
                                            </datalist>           
                                    </div> 
                                    <div class="col-md-6">
                                        <label>Police Station</label>
                                        	<input list="pstation" required class="form-control" name="pstation" placeholder="Search">
                                            <datalist id="pstation">
                                                <option value="">Select</option> 
                                                 <?php
                                                    $result = $db->prepare("select distinct pstation from complaints");
                                                    $result->execute();
                                                    for($i=0; $rows = $result->fetch(); $i++)
                                                    {
                                                    echo '<option>'.$rows['pstation'].'</option>';
                                                    }
                                                ?>	                                         					
                                            </datalist>   
                                    </div> 
                                </div>
                                <div class="row">                                   
                                    <div class="col-md-6">
                                        <label>Contact No</label>
                                            <input type="text"  name="contactno1" class="form-control" value="<?php echo $contactno;?>"  required pattern="[0-9]{10,10}" maxlength="10" minlength="10" >               
                                    </div> 
                                    <div class="col-md-6">
                                        <label>Contact No</label>
                                            <input type="text"  name="contactno2" class="form-control"  required pattern="[0-9]{10,10}" maxlength="10" minlength="10" >               
                                    </div> 
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <label>Address</label>
                                            <textarea name="addrs" class="form-control" required><?php echo $addrs;?></textarea>              
                                    </div> 
                                    
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>Photo</label>
                                            <input type="file"  name="photo" class="form-control" required accept=".png, .jpg, .jpeg">               
                                    </div> 
                                    <div class="col-md-6">
                                        <label>Video</label>
                                            <input type="file"  name="video" class="form-control" required accept=".mp4">               
                                    </div> 
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <label>Complaint</label>
                                        <textarea name="compl" rows="5" class="form-control" required></textarea>             
                                    </div> 
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>Disaster Date</label>
                                            <input type="date" class="form-control" name="ddate" required max="<?php echo date("Y-m-d");?>">        
                                    </div>  
                                    <div class="col-md-6">
                                        <label>Latest Photo</label>
                                            <input type="file" class="form-control" name="lphoto" required accept=".png, .jpg, .jpeg">         
                                    </div>  
                                </div>                                                                               
                                <div class="col-xs-12 text-right">
                                        <br>
                                        <input type="submit" value="Submit" class="btn float-right btn-danger text-white" style="float: right;">
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- New End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


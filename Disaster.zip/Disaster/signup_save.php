<?php
include("connect/db.php");
 	
	$Log_Id="DST".rand(9874475896,1);
 
	$name=$_POST["name"];
	$sex=$_POST["sex"];
	$age=$_POST["age"];
	$addrs=$_POST["addrs"];
	$username=$_POST["username"];
	$contactno=$_POST["contactno"];
	$password=$_POST["password"];
	$utype=$_POST["utype"];
	$date=date("Y-m-d");
	
	$stat='Pending';

	$image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
	$image_name = addslashes($_FILES['photo']['name']);
	$image_size = getimagesize($_FILES['photo']['tmp_name']);
	move_uploaded_file($_FILES["photo"]["tmp_name"], "photo/" . $_FILES["photo"]["name"]);
	$photo = $_FILES["photo"]["name"];
	
	
	
	
	
	if($utype=="Volunteer")
	{
	$sql = "insert into volunteer(Log_Id,name,sex,age,addrs,username,contactno,password,photo,stat,utype,date)values('$Log_Id','$name','$sex','$age','$addrs','$username','$contactno','$password','$photo','$stat','$utype','$date')";
	$q1 = $db->prepare($sql);
	$q1->execute();
	}
	else
	{
	$sql = "insert into people(Log_Id,name,sex,age,addrs,username,contactno,password,photo,stat,utype,date)values('$Log_Id','$name','$sex','$age','$addrs','$username','$contactno','$password','$photo','Active','$utype','$date')";
	$q1 = $db->prepare($sql);
	$q1->execute();	
	}
	header("location:login.php");
?>


<?php
include("../../connect/db.php");

	$name=$_POST["name"];
	$subj=$_POST["subj"];
	$about=$_POST["about"];
	$Log_Id=$_POST["Log_Id"];
	$photo=$_POST["photo"];
	
	$date=date("d-m-Y");
	
	date_default_timezone_set('Asia/Kolkata');
	$tm = date( 'h:i:s A', time () );

	
$sql = "insert into notification(name,subj,about,date,tm,Log_Id,photo)values('$name','$subj','$about','$date','$tm','$Log_Id','$photo')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../notification_search.php");
?>

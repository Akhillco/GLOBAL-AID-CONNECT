<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_VOL_ID'];
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <div class="col-md-6 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Missing People Search</h4>
                            <hr>
                            <form method="post" action="missing_view.php" class="forms" autocomplete="off">   
                                <div class="col-md-12">
                                    <label>Name</label>
                                        <input list="pname" required class="form-control" name="pname">
                                        <datalist id="pname">
                                            <option value="">Select</option> 
                                              <?php
                                               $result = $db->prepare("SELECT distinct(pname) FROM messing_people");
                                                    $result->execute();
                                                    $row_count =  $result->rowcount();
                                                    for($i=0; $rows = $result->fetch(); $i++)
                                                    {
                                                    echo '<option>'.$rows['pname'].'</option>';
                                                    }
                                                ?>	                                 					
                                        </datalist>               
                                </div>                                                                                 
                                <div class="col-md-12 col-sm-6 col-xs-6">
                                    <br>
                                    <div class="col-md-12 col-sm-6 col-xs-12">
                                        <input type="submit" value="Search" class="btn btn-block btn-primary" style="float:right">
                                    </div>                          
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- New End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


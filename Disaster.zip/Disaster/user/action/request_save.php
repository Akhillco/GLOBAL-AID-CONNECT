<?php
include("../../connect/db.php");
	
	$Log_Id=$_POST["Log_Id"];
	$name=$_POST["name"];
	$cntno=$_POST["cntno"];
	$addr=$_POST["addr"];
	$subj=$_POST["subj"];
	$fdate=$_POST["fdate"];
	$tdate=$_POST["tdate"];
	$ttime=$_POST["ttime"];
	$servce=$_POST["servce"];
	$rstatus="Pending";
	
	$image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
	$image_name = addslashes($_FILES['photo']['name']);
	$image_size = getimagesize($_FILES['photo']['tmp_name']);
	move_uploaded_file($_FILES["photo"]["tmp_name"], "../../photo/" . $_FILES["photo"]["name"]);
	$photo = $_FILES["photo"]["name"];
	
		
$sql = "insert into rquest_register(Log_Id,name,cntno,addr,subj,fdate,tdate,ttime,photo,servce,rstatus)values('$Log_Id','$name','$cntno','$addr','$subj','$fdate','$tdate','$ttime','$photo','$servce','$rstatus')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../request_post.php");
?>

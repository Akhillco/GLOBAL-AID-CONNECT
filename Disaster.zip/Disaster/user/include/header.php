
<nav class="navbar col-lg-12 col-12 px-0 py-4 d-flex flex-row">
    <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
      <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
        <span class="mdi mdi-menu"></span>
      </button>
      <div class="navbar-brand-wrapper">
        <a class="navbar-brand brand-logo" href="index.php"></a>
       </div>
      <h4 class="font-weight-bold mb-0 d-none d-md-block mt-1">Welcome back, to centralized monitor</h4>
      <ul class="navbar-nav navbar-nav-right">
        <li class="nav-item">
          <h4 class="mb-0 font-weight-bold d-none d-xl-block">Mar 12, 2025</h4>
        </li>
        <li class="nav-item dropdown me-1">
          <a class="nav-link count-indicator dropdown-toggle d-flex justify-content-center align-items-center" id="messageDropdown" href="#" data-bs-toggle="dropdown">
            <i class="mdi mdi-calendar mx-0"></i>
            <span class="count bg-info">2</span>
          </a>
          <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="messageDropdown">
            <p class="mb-0 font-weight-normal float-left dropdown-header">Messages</p>
             <?php 
				$result = $db->prepare("select * from message where Log_Id='$Log_Id' limit 3");
				$result->execute();
				for ($i = 0; $row = $result->fetch(); $i++) 
				{
			 ?>  
            <a class="dropdown-item preview-item" href="message_view.php">
              <div class="preview-thumbnail">
                  <img src="../photo/<?php echo $row["photo"];?>" alt="image" class="profile-pic">
              </div>
              <div class="preview-item-content flex-grow">
                <h6 class="preview-subject ellipsis font-weight-normal"><?php echo $row["name"];?>
                </h6>
                <p class="font-weight-light small-text text-muted mb-0">
                 <?php echo $row["subj"];?>
                </p>
              </div>
            </a>
            <?php }?>
          </div>
        </li>
        <li class="nav-item dropdown me-2">
          <a class="nav-link count-indicator dropdown-toggle d-flex align-items-center justify-content-center" id="notificationDropdown" href="#" data-bs-toggle="dropdown">
            <i class="mdi mdi-email-open mx-0"></i>
            <span class="count bg-danger">1</span>
          </a>
          <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown">
            <p class="mb-0 font-weight-normal float-left dropdown-header">Notifications</p>
             <?php 
				$result = $db->prepare("select * from notification limit 3");
				$result->execute();
				for ($i = 0; $row = $result->fetch(); $i++) 
				{
			 ?>  
            <a class="dropdown-item preview-item">
              <div class="preview-thumbnail">
                <div class="preview-icon bg-success">
                  <i class="mdi mdi-information mx-0"></i>
                </div>
              </div>
              <div class="preview-item-content">
                <h6 class="preview-subject font-weight-normal"><?php echo $row["subj"];?></h6>
                <p class="font-weight-light small-text mb-0 text-muted">
                  <?php echo $row["tm"];?>
                </p>
              </div>
            </a>
			<?php }?>
          </div>
        </li>
      </ul>
      <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
        <span class="mdi mdi-menu"></span>
      </button>
    </div>
    <div class="navbar-menu-wrapper navbar-search-wrapper d-none d-lg-flex align-items-center">
      <ul class="navbar-nav mr-lg-2">
        <li class="nav-item nav-search d-none d-lg-block">
          <div class="input-group">
            <form>
            <input type="text" class="form-control" placeholder="Search Here..." aria-label="search" aria-describedby="search">

            </form>
          </div>
        </li>
      </ul>
      <ul class="navbar-nav navbar-nav-right">
        <li class="nav-item nav-profile dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
            <img src="../photo/<?php echo $sheadphoto;?>" alt="profile"/>
            <span class="nav-profile-name"><?php echo $sheadname;?></span>
          </a>
          <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
            <a class="dropdown-item" href="profile_settings.php">
              <i class="mdi mdi-settings text-primary"></i>
              Settings
            </a>
            <a class="dropdown-item" href="../index.php">
              <i class="mdi mdi-logout text-primary"></i>
              Logout
            </a>
          </div>
        </li>
        
        
      </ul>
    </div>
  </nav>
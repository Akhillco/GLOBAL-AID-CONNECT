<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_ADMIN_ID'];
	$result = $db->prepare("select * from admin where Log_Id='$Log_Id'");
	$result->execute();
	for ($i = 0; $row = $result->fetch(); $i++) 
	{
			
		$name= $row['name'];
		$location= $row['location'];
		$addrs= $row['addrs'];
		$contact= $row['contact'];
		$email= $row['email'];
		$photo= $row['photo'];
		$about= $row['about'];
		$username = $row['username'];
		$password = $row['password'];
		
	}
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row start -->
          <div class="col-md-12 col-xl-7 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">                  
                  <ul class="nav nav-pills nav-pills-success" id="pills-tab" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link active" id="personal" data-bs-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Personal Details</a>
                    </li>                                        
                  </ul>
                  <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="personal" role="tabpanel" aria-labelledby="pills-home-tab">
                      <div class="media">
                        <img class="me-3 w-25 rounded" src="../photo/<?php echo $photo;?>" alt="sample image">
                        <div class="media-body">
                          <h5 class="mt-0"><?php echo $name;?></h5>
                          <p><?php echo $about;?>.</p>
                          <a href="profile_settings_update.php" class="btn btn-primary" style="position:relative; float:right">Settings</a>
                        </div>
                      </div>
                    </div>                    
                  </div>
                </div>
              </div>
            </div>
          <!-- row end -->
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


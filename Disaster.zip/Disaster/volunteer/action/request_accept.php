<?php
	include("../auth.php");
	include('../../connect/db.php');
	$RLog_Id = $_SESSION['SESS_VOL_ID'];
	$result = $db->prepare("select * from volunteer where Log_Id='$RLog_Id'");
	$result->execute();
	for ($i = 0; $row = $result->fetch(); $i++) 
	{
		 $rname=$row["name"];
		 $raddr=$row["addrs"];
		 $rcntno=$row["contactno"];
	}
	
	$req_id=$_GET["req_id"];	
	$rstatus="Accept";
	
	
		
$sql = "update rquest_register set RLog_Id='$RLog_Id',rname='$rname',raddr='$raddr',rcntno='$rcntno',rstatus='$rstatus' where req_id='$req_id'";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../request_confirm.php");
?>

<?php
session_start();
if(!isset($_SESSION['SESS_VOL_ID']) || (trim($_SESSION['SESS_VOL_ID']) == '')) {
	header("location:../../");
	exit();
}

?>

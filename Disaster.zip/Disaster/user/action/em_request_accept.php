<?php
	include("../auth.php");
	include('../../connect/db.php');
	$Log_Id = $_SESSION['SESS_USER_ID'];
	$result = $db->prepare("select * from people where Log_Id='$Log_Id'");
	$result->execute();
	for ($i = 0; $row = $result->fetch(); $i++) 
	{
		 $name=$row["name"];
		 $addr=$row["addrs"];
		 $cntno=$row["contactno"];
		 $photo=$row["photo"];
	}
	
	$req_id=$_GET["req_id"];	
	$qty=$_GET["qty"];	
	$fdate=$_GET["tdate"];
	
	$result = $db->prepare("select * from rquest_emergncy where req_id='$req_id'");
	$result->execute();
	for ($i = 0; $row = $result->fetch(); $i++) 
	{
		 $accqty=$row["qty"];
	}
		
	$bal=$accqty-$qty;

$sql = "update rquest_emergncy set qty='$bal' where req_id='$req_id'";
$q1 = $db->prepare($sql);
$q1->execute();



$sql = "insert into em_accept(Log_Id,name,cntno,addr,fdate,photo,qty)values('$Log_Id','$name','$cntno','$addr','$fdate','$photo','$qty')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../em_request_confirm.php");
?>

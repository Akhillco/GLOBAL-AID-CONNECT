<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_DEPT_ID'];
	$msg_id=$_GET["msg_id"];
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row end -->
            <div class="row">
                <!-- New Request -->
                <div class="col-md-6 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Reply Message</h4>
                            <hr>
                            <form method="post" action="action/message_save.php" class="forms" autocomplete="off">                                                          
                                <div class="col-md-12">
                                    <label>Reply</label>
                                    <input type="hidden" value="<?php echo $msg_id?>" name="msg_id">
                                    <textarea  name="reply" required class="form-control" rows="5"></textarea>
                                </div>                                                   
                                <div class="col-xs-12 text-right">
                                        <br>
                                        <input type="submit" value="Send" style="float: right;" class="btn float-right btn-info">
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- New End -->
            
            </div>
        
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>


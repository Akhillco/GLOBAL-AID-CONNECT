<?php
	include("auth.php");
	include('../connect/db.php');
	$Log_Id = $_SESSION['SESS_DEPT_ID'];
	$departmnt= $_POST['departmnt'];
	$result = $db->prepare("select * from department where departmnt='$departmnt'");
	$result->execute();
	for ($i = 0; $row = $result->fetch(); $i++) 
	{
		 $name=$row["name"];
		 $cntno1=$row["cntno1"];
		 $cntno2=$row["cntno2"];
		 $addr=$row["addr"];
		 $email=$row["email"];
		 $photo=$row["photo"];	
	}
?>	
<!DOCTYPE html>
<html lang="en">
<head>
 <?php 
    include("include/css.php");
 ?>
</head>
<body>
  <div class="container-scroller d-flex">
    <!-- partial:partials/_sidebar.html -->
    <?php 
        include("include/sidebar.php");
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
       
      <!-- partial -->
      <!-- partial:partials/_navbar.html -->
    
      <!-- partial -->
    <div class="main-panel">
        <div class="content-wrapper">
          <!-- row start -->
          <div class="col-md-12 col-xl-9 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">                  
                  <ul class="nav nav-pills nav-pills-success" id="pills-tab" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link active" id="personal">Department Details</a>
                    </li>                                        
                  </ul>
                  <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="personal" role="tabpanel" aria-labelledby="pills-home-tab">
                      <div class="media">
                        <img class="me-3 w-25 rounded" src="../photo/<?php echo $photo;?>" alt="sample image">
                        <div class="media-body">
                         	<table class="table table-primary">
                            	<thead>
                                	<tr>
                                    	<th>Name</th>
                                        <th>Contact</th>
                                        <th>Contact</th>
                                        <th>Address</th>
                                        <th>Email</th>
                                    </tr>
                                </thead>
                                <tbody>
                                	<tr>
                                    	<td><?php echo $name;?></td>
                                        <td><?php echo $cntno1;?></td>
                                        <td><?php echo $cntno2;?></td>
                                        <td><?php echo $addr;?></td>
                                        <td><?php echo $email;?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                      </div>
                    </div>                    
                  </div>
                </div>
              </div>
            </div>
          <!-- row end -->
        </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <?php
    include("include/js.php")
  ?>
</body>

</html>

